package com.kshitij.minilauncher

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.BatteryManager
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import java.util.Calendar
import java.util.Locale

/** Thin rounded progress bar (battery level). */
class BarView(context: Context, private val track: Int, private val fillColor: Int) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var frac: Float = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    override fun onDraw(canvas: Canvas) {
        val h = height.toFloat()
        val w = width.toFloat()
        p.color = track
        canvas.drawRoundRect(RectF(0f, 0f, w, h), h / 2, h / 2, p)
        p.color = fillColor
        canvas.drawRoundRect(RectF(0f, 0f, w * frac, h), h / 2, h / 2, p)
    }
}

/** Dashboard-style home widgets: Clock and Date, Go To bar, Battery and Calendar tiles. */
class Widgets(private val ui: Ui) {

    private val ctx: Context = ui.ctx
    private lateinit var batteryValue: TextView
    private lateinit var batteryState: TextView
    private lateinit var batteryBar: BarView
    private lateinit var calDay: TextView
    private lateinit var calSub: TextView
    private lateinit var calWeek: TextView

    private fun label(text: String): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = 11f
        t.letterSpacing = 0.14f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setTextColor(ui.pal.sub)
        return t
    }

    // ---- Clock and Date ----
    fun clock(onLong: () -> Unit): View {
        val card = FrameLayout(ctx)
        card.background = ui.cardBg(16)
        card.clipToOutline = true
        card.elevation = ui.pxf(3f)
        card.setOnLongClickListener { onLong(); true }

        card.addView(SwooshView(ctx, SwooshView.CORNER_SMALL), FrameLayout.LayoutParams(ui.px(200), ui.px(160), Gravity.BOTTOM or Gravity.END))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL

        val strip = TextView(ctx)
        strip.text = "TODAY"
        strip.textSize = 11f
        strip.letterSpacing = 0.22f
        strip.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        strip.setTextColor(Color.WHITE)
        strip.setBackgroundColor(Tally.BLUE)
        strip.gravity = Gravity.CENTER_VERTICAL
        strip.setPadding(ui.px(18), 0, ui.px(18), 0)
        col.addView(strip, LinearLayout.LayoutParams(-1, ui.px(22)))

        val clock = TextClock(ctx)
        clock.format12Hour = "h:mm"
        clock.format24Hour = "HH:mm"
        clock.textSize = 38f
        clock.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        clock.setTextColor(ui.pal.text)
        clock.setPadding(ui.px(18), ui.px(6), 0, 0)
        col.addView(clock)

        val date = TextClock(ctx)
        date.format12Hour = "EEEE, d MMMM"
        date.format24Hour = "EEEE, d MMMM"
        date.textSize = 14f
        date.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        date.setTextColor(ui.pal.text)
        date.background = ui.highlight()
        date.setPadding(ui.px(16), ui.px(4), ui.px(16), ui.px(4))
        val dlp = LinearLayout.LayoutParams(-2, -2)
        dlp.setMargins(ui.px(14), ui.px(0), 0, ui.px(12))
        col.addView(date, dlp)

        card.addView(col, FrameLayout.LayoutParams(-1, -2))
        return card
    }

    // ---- Go To bar ----
    fun goTo(onClick: () -> Unit): View {
        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(ui.px(18), 0, ui.px(14), 0)
        bar.background = ui.cardBg(26, ui.pal.surface, Tally.BLUE, 2)
        bar.elevation = ui.pxf(4f)
        bar.isClickable = true
        bar.setOnClickListener { onClick() }
        bar.addView(SearchIconView(ctx, Tally.BLUE), LinearLayout.LayoutParams(ui.px(20), ui.px(20)))

        val t = TextView(ctx)
        t.text = "Go To  \u2013  apps or web"
        t.textSize = 16f
        t.setTextColor(ui.pal.text)
        t.setPadding(ui.px(12), 0, 0, 0)
        bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))

        val chip = TextView(ctx)
        chip.text = "Alt+G"
        chip.textSize = 10f
        chip.setTextColor(ui.pal.label)
        chip.background = ui.cardBg(8, Color.TRANSPARENT, Tally.BLUE, 1)
        chip.setPadding(ui.px(8), ui.px(3), ui.px(8), ui.px(3))
        bar.addView(chip)
        return bar
    }

    // ---- Battery + Calendar tiles ----
    private fun tile(accent: Int, title: String): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.background = ui.cardBg(14)
        c.elevation = ui.pxf(2f)
        c.setPadding(ui.px(16), ui.px(12), ui.px(16), ui.px(14))
        val accentBar = View(ctx)
        accentBar.background = ui.cardBg(2, accent, accent, 0)
        c.addView(accentBar, LinearLayout.LayoutParams(ui.px(28), ui.px(4)))
        val l = label(title)
        l.setPadding(0, ui.px(8), 0, ui.px(6))
        c.addView(l)
        val div = View(ctx)
        div.setBackgroundColor(ui.pal.border)
        c.addView(div, LinearLayout.LayoutParams(-1, ui.px(1)))
        return c
    }

    fun stats(onCalendar: () -> Unit): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL

        val bat = tile(Tally.CYAN, "BATTERY")
        batteryValue = TextView(ctx)
        batteryValue.textSize = 30f
        batteryValue.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        batteryValue.setTextColor(ui.pal.text)
        batteryValue.setPadding(0, ui.px(6), 0, 0)
        bat.addView(batteryValue)
        batteryBar = BarView(ctx, ui.pal.border, Tally.CYAN)
        val blp = LinearLayout.LayoutParams(-1, ui.px(6))
        blp.setMargins(0, ui.px(4), 0, ui.px(6))
        bat.addView(batteryBar, blp)
        batteryState = TextView(ctx)
        batteryState.textSize = 12f
        batteryState.setTextColor(ui.pal.sub)
        bat.addView(batteryState)

        val cal = tile(Tally.BLUE, "CALENDAR")
        cal.isClickable = true
        cal.setOnClickListener { onCalendar() }
        calDay = TextView(ctx)
        calDay.textSize = 30f
        calDay.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        calDay.setTextColor(ui.pal.text)
        calDay.setPadding(0, ui.px(6), 0, 0)
        cal.addView(calDay)
        calSub = TextView(ctx)
        calSub.textSize = 13f
        calSub.setTextColor(ui.pal.text)
        calSub.setPadding(0, ui.px(10), 0, 0)
        cal.addView(calSub)
        calWeek = TextView(ctx)
        calWeek.textSize = 12f
        calWeek.setTextColor(ui.pal.sub)
        cal.addView(calWeek)

        val lp1 = LinearLayout.LayoutParams(0, -1, 1f)
        lp1.setMargins(0, 0, ui.px(6), 0)
        val lp2 = LinearLayout.LayoutParams(0, -1, 1f)
        lp2.setMargins(ui.px(6), 0, 0, 0)
        row.addView(bat, lp1)
        row.addView(cal, lp2)
        updateCalendar()
        return row
    }

    fun updateBattery(i: Intent?) {
        if (i == null || !::batteryValue.isInitialized) return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        if (level < 0 || scale <= 0) return
        val pct = level * 100 / scale
        batteryValue.text = "$pct%"
        batteryBar.frac = pct / 100f
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        batteryState.text = if (charging) "Charging" else "On battery"
    }

    fun updateCalendar() {
        if (!::calDay.isInitialized) return
        val c = Calendar.getInstance()
        calDay.text = c.get(Calendar.DAY_OF_MONTH).toString()
        val dow = c.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.SHORT, Locale.getDefault()) ?: ""
        val mon = c.getDisplayName(Calendar.MONTH, Calendar.SHORT, Locale.getDefault()) ?: ""
        calSub.text = "${dow.uppercase()} \u00B7 ${mon.uppercase()} ${c.get(Calendar.YEAR)}"
        calWeek.text = "Week ${c.get(Calendar.WEEK_OF_YEAR)}"
    }
}
