package com.kshitij.minilauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/**
 * Smooth, overlapping ribbon swooshes. Every ribbon is a tapered crescent made of two cubic Bezier
 * curves that share their end points, so the tips are pointed and the body is fluid.
 * Paths are built once in onSizeChanged; onDraw only draws them.
 */
class SwooshView(context: Context, private val kind: Int) : View(context) {

    companion object {
        const val HEADER_HOME = 0
        const val HEADER_DRAWER = 1
        const val HEADER_SHADE = 2
        const val FOOTER_BIG = 3
        const val FOOTER_SLIM = 4
        const val GOLD_DIV = 5        // kept for call-site compatibility; draws the cyan divider
        const val TEAL_DIV = 6
        const val CORNER_SMALL = 7
        /** Bottom-right corner swoosh for Home and the App Tray. Never takes touches. */
        const val CORNER_BR = 8
    }

    private val paths = ArrayList<Path>()
    private val paints = ArrayList<Paint>()

    private fun fill(color: Int, alpha: Int = 255): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        p.color = color
        p.alpha = alpha
        return p
    }

    private fun add(path: Path, color: Int, alpha: Int = 255) {
        paths.add(path)
        paints.add(fill(color, alpha))
    }

    /**
     * Crescent between an outer and an inner cubic that share both end points.
     * out* / in* shift the control points vertically (positive = down), which sets thickness.
     */
    private fun ribbon(
        x0: Float, y0: Float, c1x: Float, c1y: Float, c2x: Float, c2y: Float, x1: Float, y1: Float,
        out1: Float, out2: Float, in1: Float, in2: Float
    ): Path {
        val p = Path()
        p.moveTo(x0, y0)
        p.cubicTo(c1x, c1y + out1, c2x, c2y + out2, x1, y1)
        p.cubicTo(c2x, c2y + in2, c1x, c1y + in1, x0, y0)
        p.close()
        return p
    }

    /** Body whose lower edge is a smooth S-curve. */
    private fun navyBody(w: Float, h: Float): Path {
        val p = Path()
        p.moveTo(0f, 0f)
        p.lineTo(w, 0f)
        p.lineTo(w, h * 0.42f)
        p.cubicTo(w * 0.70f, h * 0.86f, w * 0.36f, h * 0.34f, 0f, h * 0.73f)
        p.close()
        return p
    }

    /** A ribbon that follows the body edge, shifted down by s, with its own start/end. */
    private fun edgeRibbon(
        w: Float, h: Float, s: Float, xs: Float, xe: Float, thick: Float, inner: Float
    ): Path = ribbon(
        w * xs, h * 0.73f + s, w * 0.36f, h * 0.34f + s, w * 0.70f, h * 0.86f + s, w * xe, h * 0.40f + s,
        thick, thick, inner, inner
    )

    private fun header(w: Float, h: Float, withCoral: Boolean, tealFirst: Boolean) {
        // soft decorative arcs inside the header body
        add(ribbon(-w * 0.05f, h * 0.50f, w * 0.30f, h * 0.08f, w * 0.65f, h * 0.50f, w * 1.05f, h * 0.06f,
            h * 0.08f, h * 0.08f, 0f, 0f), Tally.INK, 0x14)
        add(ribbon(-w * 0.05f, h * 0.62f, w * 0.34f, h * 0.22f, w * 0.68f, h * 0.64f, w * 1.05f, h * 0.22f,
            h * 0.06f, h * 0.06f, 0f, 0f), Tally.BLUE, 0x66)
        val sp = h * 0.040f
        val t = h * 0.085f
        val inn = -h * 0.035f
        val c0 = if (tealFirst) Tally.CYAN else Tally.MINT
        val c1 = if (tealFirst) Tally.BLUE else Tally.CYAN
        val c2 = if (tealFirst) Tally.MINT else Tally.BLUE
        // back to front: each ribbon tucks under the one above it
        if (withCoral) add(edgeRibbon(w, h, sp * 3f, 0.12f, 0.88f, h * 0.05f, -h * 0.02f), Tally.BLUSH, 0xE6)
        add(edgeRibbon(w, h, sp * 2f, 0.02f, 0.97f, t, inn), c0)
        add(edgeRibbon(w, h, sp * 1f, 0.00f, 1.03f, t, inn), c1)
        add(edgeRibbon(w, h, 0f, 0.03f, 1.05f, t, inn), c2)
        add(navyBody(w, h), Tally.headerBody())
    }

    /** One long S-shaped ribbon sweeping from the lower left to the upper right. */
    private fun band(w: Float, h: Float, o: Float, t: Float, x0: Float, x1: Float): Path = ribbon(
        w * x0, h * 0.98f - o, w * 0.30f, h * 1.12f - o, w * 0.62f, h * 0.35f - o, w * x1, h * 0.55f - o,
        -t, -t, 0f, 0f
    )

    private fun footer(w: Float, h: Float, full: Boolean) {
        if (full) {
            add(band(w, h, h * 0.34f, h * 0.10f, 0.10f, 0.95f), Tally.BLUSH, 0xA6)
            add(band(w, h, h * 0.25f, h * 0.14f, 0.04f, 1.02f), Tally.MINT, 0xBF)
            add(band(w, h, h * 0.14f, h * 0.16f, -0.02f, 1.05f), Tally.CYAN, 0xBF)
            add(band(w, h, 0f, h * 0.18f, -0.05f, 1.05f), Tally.BLUE, 0xBF)
        } else {
            add(band(w, h, h * 0.30f, h * 0.20f, 0.06f, 1.00f), Tally.MINT, 0xBF)
            add(band(w, h, h * 0.15f, h * 0.24f, 0.00f, 1.05f), Tally.CYAN, 0xBF)
            add(band(w, h, 0f, h * 0.26f, -0.05f, 1.05f), Tally.BLUE, 0xBF)
        }
    }

    /** Thin S-shaped ribbon used as a divider. */
    private fun divider(w: Float, h: Float, main: Int, second: Int) {
        add(ribbon(0f, h * 0.78f, w * 0.30f, h * 0.05f, w * 0.65f, h * 0.95f, w, h * 0.28f,
            h * 0.22f, h * 0.22f, -h * 0.02f, -h * 0.02f), main)
        add(ribbon(w * 0.04f, h * 0.88f, w * 0.34f, h * 0.30f, w * 0.60f, h * 0.98f, w * 0.78f, h * 0.60f,
            h * 0.10f, h * 0.10f, 0f, 0f), second, 0xE6)
    }

    /**
     * Single-colour tapered swoosh: the outer curve is offset by [t] and the inner curve is the
     * centreline. Both share their end points, so the ends come to a point. Fractions of the view.
     */
    private fun taper(w: Float, h: Float, color: Int, x0: Float, y0: Float,
                      c1x: Float, c1y: Float, c2x: Float, c2y: Float,
                      x1: Float, y1: Float, t: Float) {
        val p = Path()
        p.moveTo(w * x0, h * y0)
        p.cubicTo(w * c1x, h * (c1y - t), w * c2x, h * (c2y - t), w * x1, h * y1)
        p.cubicTo(w * c2x, h * c2y, w * c1x, h * c1y, w * x0, h * y0)
        p.close()
        add(p, color)
    }

    /** Bottom-right corner pair for Home and the App Tray: a red and a blue swoosh that cross. */
    private fun corner(w: Float, h: Float) {
        taper(w, h, Tally.BLUE, 0.00f, 0.62f, 0.40f, 0.60f, 0.70f, 0.95f, 1.12f, 1.08f, 0.05f)
        taper(w, h, Tally.BLUE, 0.02f, 1.10f, 0.40f, 0.92f, 0.78f, 0.42f, 1.10f, 0.18f, 0.05f)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        paths.clear()
        paints.clear()
        val fw = w.toFloat()
        val fh = h.toFloat()
        when (kind) {
            // header keeps its navy band only; no ribbons
            HEADER_HOME, HEADER_SHADE, HEADER_DRAWER -> add(navyBody(fw, fh), Tally.headerBody())
            // the swoosh is the crossing pair in the bottom-right corner
            CORNER_SMALL, CORNER_BR -> corner(fw, fh)
            // footers and dividers carry no swoosh
            else -> {}
        }
    }

    override fun onDraw(canvas: Canvas) {
        for (i in 0 until paths.size) canvas.drawPath(paths[i], paints[i])
    }
}

/** Small crisp magnifier icon for the Go To search bar. */
class SearchIconView(context: Context, color: Int) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.color = color
    }

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height).toFloat()
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        p.strokeWidth = s * 0.11f
        val r = s * 0.30f
        val cx = ox + s * 0.42f
        val cy = oy + s * 0.42f
        canvas.drawCircle(cx, cy, r, p)
        canvas.drawLine(cx + r * 0.72f, cy + r * 0.72f, ox + s * 0.88f, oy + s * 0.88f, p)
    }
}
