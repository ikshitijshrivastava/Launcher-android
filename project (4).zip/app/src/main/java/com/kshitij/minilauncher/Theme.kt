package com.kshitij.minilauncher

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity

/** TallyPrime-inspired colour tokens. Light and dark palettes are chosen at runtime. */
object Tally {
    val NAVY: Int = Color.parseColor("#0B3B8C")   // header navy
    val DEEP: Int = Color.parseColor("#1A3E70")   // deep Tally blue (strips, active tiles)
    val SKY: Int = Color.parseColor("#2B7DE9")
    val GOLD: Int = Color.parseColor("#F7B500")
    val TEAL: Int = Color.parseColor("#00A88F")
    val TEAL2: Int = Color.parseColor("#03979D")
    val CORAL: Int = Color.parseColor("#F26522")

    class Palette(
        val bg: Int,
        val surface: Int,
        val text: Int,
        val sub: Int,
        val label: Int,
        val onHeader: Int,
        val onHeaderSub: Int,
        val border: Int,
        val tints: IntArray   // icon tints cycled per app
    )

    fun palette(dark: Boolean): Palette =
        if (dark) Palette(
            bg = Color.parseColor("#0A1628"),
            surface = Color.parseColor("#13233D"),
            text = Color.parseColor("#E8F1FF"),
            sub = Color.parseColor("#8FA8CC"),
            label = GOLD,
            onHeader = Color.WHITE,
            onHeaderSub = Color.parseColor("#BFD4F5"),
            border = Color.parseColor("#223A5E"),
            tints = intArrayOf(
                Color.parseColor("#8FB8FF"), Color.parseColor("#5FA0FF"),
                Color.parseColor("#2FD0D6"), GOLD
            )
        ) else Palette(
            bg = Color.parseColor("#F4F7FC"),
            surface = Color.parseColor("#FFFFFF"),
            text = Color.parseColor("#1E293B"),
            sub = Color.parseColor("#64748B"),
            label = NAVY,
            onHeader = Color.WHITE,
            onHeaderSub = Color.parseColor("#CFE0FF"),
            border = Color.parseColor("#DCE6F5"),
            tints = intArrayOf(DEEP, SKY, TEAL2, GOLD)
        )

    fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)
}

/** Small helper shared by every screen: dp conversion, palette and common drawables. */
class Ui(val ctx: Context, val dark: Boolean) {
    val pal: Tally.Palette = Tally.palette(dark)
    private val d = ctx.resources.displayMetrics.density

    fun px(v: Int): Int = (v * d).toInt()
    fun pxf(v: Float): Float = v * d

    fun cardBg(
        radiusDp: Int = 14,
        fill: Int = pal.surface,
        stroke: Int = pal.border,
        strokeDp: Int = 1
    ): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = pxf(radiusDp.toFloat())
        if (strokeDp > 0) g.setStroke(px(strokeDp), stroke)
        return g
    }

    /** TallyPrime-style highlight: soft gold pill with a gold bar on the left. */
    fun highlight(): LayerDrawable {
        val fill = GradientDrawable()
        fill.setColor(Tally.withAlpha(Tally.GOLD, 0x2E))
        fill.cornerRadius = pxf(10f)
        val bar = GradientDrawable()
        bar.setColor(Tally.GOLD)
        bar.cornerRadius = pxf(2f)
        val ld = LayerDrawable(arrayOf<Drawable>(fill, bar))
        ld.setLayerWidth(1, px(4))
        ld.setLayerGravity(1, Gravity.START or Gravity.FILL_VERTICAL)
        ld.setLayerInsetTop(1, px(8))
        ld.setLayerInsetBottom(1, px(8))
        return ld
    }

    fun stateHighlight(): StateListDrawable {
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_pressed), highlight())
        s.addState(intArrayOf(android.R.attr.state_focused), highlight())
        s.addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
        return s
    }
}
