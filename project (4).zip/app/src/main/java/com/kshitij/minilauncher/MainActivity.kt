package com.kshitij.minilauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min

class AppItem(val label: String, val pkg: String, val cls: String)
class WebRow(val query: String)

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var ui: Ui
    private lateinit var pal: Tally.Palette
    private lateinit var icons: IconProvider
    private lateinit var widgets: Widgets
    private lateinit var shade: Shade
    private var dark = false

    private var allApps: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()   // apps matching the search
    private var rows: List<Any> = emptyList()        // String = letter header, AppItem, WebRow

    private lateinit var home: FrameLayout
    private lateinit var favBox: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var list: ListView
    private lateinit var adapter: BaseAdapter
    private lateinit var gestures: GestureDetector

    private val autoLaunch: Boolean get() = prefs.getBoolean("auto", false)
    private val customShade: Boolean get() = prefs.getBoolean("customShade", true)
    private fun px(v: Int): Int = ui.px(v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun isDark(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { widgets.updateBattery(i) }
    }
    private var batteryRegistered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        dark = isDark()
        ui = Ui(this, dark)
        pal = ui.pal
        icons = IconProvider(this, ui)
        widgets = Widgets(ui)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        val root = FrameLayout(this)
        root.setBackgroundColor(pal.bg)
        buildHome()
        buildDrawer()
        shade = Shade(this, ui, { closeShade() }, { closeShade(); expandSystemShade() })
        root.addView(home, FrameLayout.LayoutParams(-1, -1))
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
        root.addView(shade.root, FrameLayout.LayoutParams(-1, -1))
        drawer.visibility = View.GONE
        setContentView(root)
        applySystemBars()

        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || drawer.visibility == View.VISIBLE || shade.isVisible) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                val min = px(80)
                if (abs(dy) > abs(dx)) {
                    if (dy < -min) openDrawer() else if (dy > min) openShadeOrSystem()
                } else {
                    if (dx < -min) openCamera() else if (dx > min) openDialer()
                }
                return true
            }
        })
        gestures.setIsLongpressEnabled(false)
    }

    /** Status bar and navigation bar colours plus light/dark icon flags to match the Tally theme. */
    @Suppress("DEPRECATION")
    private fun applySystemBars() {
        window.statusBarColor = Tally.NAVY
        window.navigationBarColor = pal.bg
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val c = window.insetsController
            if (c != null) {
                // status bar is always navy, so keep its icons light; nav bar follows the theme
                c.setSystemBarsAppearance(0, WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS)
                c.setSystemBarsAppearance(
                    if (dark) 0 else WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                )
            }
        } else {
            val v = window.decorView
            var f = v.systemUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            v.systemUiVisibility = f
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (isDark() != dark) recreate()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_G && event.isAltPressed) {
            if (shade.isVisible) closeShade()
            openDrawer()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        refreshFavs()
        filter()
        widgets.updateCalendar()
        registerBattery()
        shade.onResume()
    }

    override fun onPause() {
        super.onPause()
        unregisterBattery()
    }

    override fun onDestroy() {
        super.onDestroy()
        shade.destroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        closeDrawer()
        closeShade()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (shade.isVisible) closeShade()
        else if (drawer.visibility == View.VISIBLE) closeDrawer()
    }

    private fun registerBattery() {
        if (batteryRegistered) return
        val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val sticky = if (Build.VERSION.SDK_INT >= 33) registerReceiver(batteryReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(batteryReceiver, f)
        batteryRegistered = true
        widgets.updateBattery(sticky)
    }

    private fun unregisterBattery() {
        if (!batteryRegistered) return
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) { }
        batteryRegistered = false
    }

    // ---------- Home ----------

    private fun contentWidth(): Int = px(min(resources.configuration.screenWidthDp, 560))

    private fun buildHome() {
        home = FrameLayout(this)

        home.addView(SwooshView(this, SwooshView.FOOTER_BIG), FrameLayout.LayoutParams(-1, px(130), Gravity.BOTTOM))

        val header = SwooshView(this, SwooshView.HEADER_HOME)
        header.setOnClickListener { openShadeOrSystem() }
        header.setOnLongClickListener { showSettings(); true }
        home.addView(header, FrameLayout.LayoutParams(-1, px(140), Gravity.TOP))

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(px(16), px(4), px(16), px(40))

        // status header row: tap for the in-launcher quick settings
        val status = LinearLayout(this)
        status.orientation = LinearLayout.HORIZONTAL
        status.gravity = Gravity.CENTER_VERTICAL
        status.isClickable = true
        status.setOnClickListener { openShadeOrSystem() }
        val appName = TextView(this)
        appName.text = "MINI LAUNCHER"
        appName.textSize = 11f
        appName.letterSpacing = 0.22f
        appName.setTextColor(pal.onHeaderSub)
        status.addView(appName, LinearLayout.LayoutParams(0, -2, 1f))
        val qs = TextView(this)
        qs.text = "Quick settings \u25BE"
        qs.textSize = 12f
        qs.setTextColor(Tally.GOLD)
        status.addView(qs)
        content.addView(status, LinearLayout.LayoutParams(-1, px(36)))

        val cl = LinearLayout.LayoutParams(-1, -2)
        cl.setMargins(0, px(88), 0, 0)
        content.addView(widgets.clock { showSettings() }, cl)
        val gl = LinearLayout.LayoutParams(-1, px(52))
        gl.setMargins(0, px(14), 0, 0)
        content.addView(widgets.goTo { openDrawer() }, gl)
        val sl = LinearLayout.LayoutParams(-1, px(108))
        sl.setMargins(0, px(14), 0, 0)
        content.addView(widgets.stats {
            try {
                startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { toast("No calendar app found") }
        }, sl)

        val label = TextView(this)
        label.text = "PINNED"
        label.textSize = 12f
        label.letterSpacing = 0.15f
        label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        label.setTextColor(pal.label)
        label.setPadding(px(8), px(14), 0, 0)
        content.addView(label)
        content.addView(SwooshView(this, SwooshView.GOLD_DIV), LinearLayout.LayoutParams(-1, px(16)))

        favBox = LinearLayout(this)
        favBox.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(favBox, FrameLayout.LayoutParams(-1, -2))
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        home.addView(content, FrameLayout.LayoutParams(contentWidth(), -1, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // Tiny, non-prominent signature in the bottom-left corner.
        val sig = TextView(this)
        sig.text = "Kshitij"
        sig.textSize = 9f
        sig.letterSpacing = 0.12f
        sig.setTextColor(Tally.withAlpha(pal.sub, 120))
        val sigLp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START)
        sigLp.setMargins(px(14), 0, 0, px(10))
        home.addView(sig, sigLp)
    }

    private fun refreshFavs() {
        favBox.removeAllViews()
        val favs = getFavs().mapNotNull { p -> allApps.firstOrNull { it.pkg == p } }
        if (favs.isEmpty()) {
            val hint = TextView(this)
            hint.text = "Swipe up for all apps. Long-press an app to pin it here.\nLong-press the header for settings and to switch back to your old launcher."
            hint.setTextColor(pal.sub)
            hint.textSize = 13f
            hint.setPadding(px(8), px(8), px(8), 0)
            favBox.addView(hint)
        }
        for (a in favs) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(px(12), px(6), px(12), px(6))
            row.background = ui.stateHighlight()
            row.isFocusable = true
            val iv = ImageView(this)
            icons.bind(iv, a, true)
            row.addView(iv, LinearLayout.LayoutParams(px(44), px(44)))
            val t = TextView(this)
            t.text = a.label
            t.textSize = 19f
            t.setTextColor(pal.text)
            t.setPadding(px(16), 0, 0, 0)
            row.addView(t)
            row.setOnClickListener { launch(a) }
            row.setOnLongClickListener { showAppMenu(a); true }
            favBox.addView(row)
        }
    }

    // ---------- Drawer ----------

    private fun buildDrawer() {
        drawer = LinearLayout(this)
        drawer.orientation = LinearLayout.VERTICAL
        drawer.setBackgroundColor(pal.bg)

        val headerHolder = FrameLayout(this)
        headerHolder.addView(SwooshView(this, SwooshView.HEADER_DRAWER), FrameLayout.LayoutParams(-1, -1))

        val title = TextView(this)
        title.text = "All Apps"
        title.textSize = 18f
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.setTextColor(pal.onHeader)
        title.setPadding(px(28), px(20), 0, 0)
        headerHolder.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(px(14), 0, px(12), 0)
        bar.background = ui.cardBg(12, pal.surface, Tally.SKY, 2)
        bar.elevation = px(4).toFloat()
        bar.addView(SearchIconView(this, Tally.SKY), LinearLayout.LayoutParams(px(20), px(20)))

        search = EditText(this)
        search.hint = "Go To  \u2013  type an app name"
        search.setHintTextColor(pal.sub)
        search.setTextColor(pal.text)
        search.textSize = 18f
        search.setSingleLine(true)
        search.background = null
        search.setPadding(px(10), 0, 0, 0)
        search.imeOptions = EditorInfo.IME_ACTION_GO
        search.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter() }
        })
        search.setOnEditorActionListener { _, _, _ ->
            val q = search.text.toString().trim()
            if (shown.isNotEmpty()) launch(shown[0]) else if (q.isNotEmpty()) webSearch(q)
            true
        }
        bar.addView(search, LinearLayout.LayoutParams(0, -1, 1f))

        val barLp = FrameLayout.LayoutParams(-1, px(52), Gravity.BOTTOM)
        barLp.setMargins(px(24), 0, px(24), px(18))
        headerHolder.addView(bar, barLp)

        list = ListView(this)
        list.divider = null
        list.overScrollMode = View.OVER_SCROLL_NEVER
        list.selector = ui.highlight()
        list.setDrawSelectorOnTop(false)
        list.setPadding(px(16), px(8), px(16), px(8))
        list.clipToPadding = false

        adapter = object : BaseAdapter() {
            override fun getCount(): Int = rows.size
            override fun getItem(i: Int): Any = rows[i]
            override fun getItemId(i: Int): Long = i.toLong()
            override fun getViewTypeCount(): Int = 3
            override fun getItemViewType(i: Int): Int = when (rows[i]) {
                is String -> 0
                is AppItem -> 1
                else -> 2
            }
            override fun areAllItemsEnabled(): Boolean = false
            override fun isEnabled(i: Int): Boolean = rows[i] !is String
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val r = rows[i]
                if (r is String) {
                    val box = (v as? LinearLayout) ?: buildLetterRow()
                    (box.getChildAt(0) as TextView).text = r
                    return box
                }
                if (r is WebRow) {
                    val row = (v as? LinearLayout) ?: buildWebRow()
                    (row.getChildAt(1) as TextView).text = "Search the web for \u201C" + r.query + "\u201D"
                    return row
                }
                val a = r as AppItem
                val row = (v as? LinearLayout) ?: buildAppRow()
                icons.bind(row.getChildAt(0) as ImageView, a, a.pkg in getFavs())
                (row.getChildAt(1) as TextView).text = a.label
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, i, _ ->
            when (val r = rows[i]) {
                is AppItem -> launch(r)
                is WebRow -> webSearch(r.query)
                else -> {}
            }
        }
        list.setOnItemLongClickListener { _, _, i, _ ->
            val r = rows[i]
            if (r is AppItem) showAppMenu(r)
            true
        }

        drawer.addView(headerHolder, LinearLayout.LayoutParams(-1, px(176)))
        drawer.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        drawer.addView(SwooshView(this, SwooshView.FOOTER_SLIM), LinearLayout.LayoutParams(-1, px(44)))
    }

    private fun buildAppRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(px(12), px(7), px(12), px(7))
        row.addView(ImageView(this), LinearLayout.LayoutParams(px(44), px(44)))
        val t = TextView(this)
        t.textSize = 19f
        t.setTextColor(pal.text)
        t.setPadding(px(16), 0, 0, 0)
        row.addView(t)
        return row
    }

    private fun buildWebRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(px(12), px(7), px(12), px(7))
        val box = FrameLayout(this)
        box.background = ui.cardBg(13, pal.surface, Tally.SKY, 2)
        box.addView(SearchIconView(this, Tally.SKY), FrameLayout.LayoutParams(px(22), px(22), Gravity.CENTER))
        row.addView(box, LinearLayout.LayoutParams(px(44), px(44)))
        val t = TextView(this)
        t.textSize = 16f
        t.setTextColor(Tally.SKY)
        t.setPadding(px(16), 0, 0, 0)
        row.addView(t)
        return row
    }

    private fun buildLetterRow(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(px(4), px(14), px(4), 0)
        val t = TextView(this)
        t.textSize = 13f
        t.letterSpacing = 0.1f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        t.setTextColor(Tally.TEAL)
        t.setPadding(px(12), 0, 0, px(2))
        box.addView(t)
        box.addView(SwooshView(this, SwooshView.TEAL_DIV), LinearLayout.LayoutParams(-1, px(12)))
        return box
    }

    // ---------- Apps ----------

    private fun loadApps() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = packageManager.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppItem(
                    it.loadLabel(packageManager).toString(),
                    it.activityInfo.packageName,
                    it.activityInfo.name
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun matches(label: String, q: String): Boolean {
        if (label.contains(q)) return true
        var i = 0
        for (c in label) {
            if (i < q.length && c == q[i]) i++
        }
        return i == q.length
    }

    private fun group(apps: List<AppItem>): List<Any> {
        val out = ArrayList<Any>()
        var last = ""
        for (a in apps) {
            val c = a.label.trim().firstOrNull()?.uppercaseChar()
            val key = if (c != null && c.isLetter()) c.toString() else "#"
            if (key != last) {
                out.add(key)
                last = key
            }
            out.add(a)
        }
        return out
    }

    private fun filter() {
        val q = search.text.toString().trim().lowercase()
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        val base = allApps.filter { it.pkg !in hidden }
        shown = if (q.isEmpty()) base
        else base.filter { matches(it.label.lowercase(), q) }
            .sortedBy { if (it.label.lowercase().startsWith(q)) 0 else 1 }
        if (q.isEmpty()) {
            rows = group(shown)
        } else {
            val r = ArrayList<Any>(shown)
            r.add(WebRow(search.text.toString().trim()))
            rows = r
        }
        adapter.notifyDataSetChanged()
        if (autoLaunch && q.length >= 2 && shown.size == 1) launch(shown[0])
    }

    private fun webSearch(q: String) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) { toast("No browser found") }
        closeDrawer()
    }

    private fun launch(a: AppItem) {
        try {
            val i = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(a.pkg, a.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(i)
        } catch (e: Exception) {
            toast("Can't open ${a.label}")
        }
        closeDrawer()
    }

    private fun getFavs(): List<String> =
        (prefs.getString("favs", "") ?: "").split("\n").filter { it.isNotEmpty() }

    private fun setFavs(l: List<String>) {
        prefs.edit().putString("favs", l.joinToString("\n")).apply()
    }

    @Suppress("DEPRECATION")
    private fun dialogTheme(): Int =
        if (dark) AlertDialog.THEME_DEVICE_DEFAULT_DARK else AlertDialog.THEME_DEVICE_DEFAULT_LIGHT

    private fun showAppMenu(a: AppItem) {
        val isFav = a.pkg in getFavs()
        val items = arrayOf(
            if (isFav) "Remove from home" else "Pin to home",
            "Hide",
            "App info",
            "Uninstall"
        )
        AlertDialog.Builder(this, dialogTheme())
            .setTitle(a.label)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        val f = getFavs().toMutableList()
                        if (isFav) f.remove(a.pkg)
                        else if (f.size >= 6) toast("Home is full (6 apps)")
                        else f.add(a.pkg)
                        setFavs(f)
                    }
                    1 -> {
                        val s = HashSet(prefs.getStringSet("hidden", emptySet()) ?: emptySet())
                        s.add(a.pkg)
                        prefs.edit().putStringSet("hidden", s).apply()
                        setFavs(getFavs().filter { it != a.pkg })
                        toast("Hidden. Unhide from the header long-press menu.")
                    }
                    2 -> safe {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
                        )
                    }
                    3 -> safe {
                        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                    }
                }
                refreshFavs()
                filter()
            }
            .show()
    }

    private fun showSettings() {
        val items = arrayOf(
            "Switch back to default launcher",
            "Swipe down opens: " + (if (customShade) "Quick panel" else "System shade"),
            "Auto-open single search match: " + (if (autoLaunch) "ON" else "OFF"),
            "Unhide all apps",
            "System settings"
        )
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("Mini Launcher")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> switchLauncher()
                    1 -> prefs.edit().putBoolean("customShade", !customShade).apply()
                    2 -> prefs.edit().putBoolean("auto", !autoLaunch).apply()
                    3 -> { prefs.edit().remove("hidden").apply(); filter() }
                    4 -> safe { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                }
            }
            .show()
    }

    private fun switchLauncher() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                Toast.makeText(
                    this,
                    "Open Apps > Default apps > Home app and pick your old launcher",
                    Toast.LENGTH_LONG
                ).show()
            } catch (e2: Exception) {
                toast("Open Settings > Apps > Default apps > Home app")
            }
        }
    }

    // ---------- Drawer, shade + gestures ----------

    private fun openDrawer() {
        drawer.visibility = View.VISIBLE
        search.requestFocus()
        search.post {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closeDrawer() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.setText("")
        drawer.visibility = View.GONE
    }

    private fun openShadeOrSystem() {
        if (customShade) shade.show() else expandSystemShade()
    }

    private fun closeShade() = shade.hide()

    private fun expandSystemShade() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager")
                .getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) {
            toast("Pull down from the top edge")
        }
    }

    private fun openCamera() = safe { startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
    private fun openDialer() = safe { startActivity(Intent(Intent.ACTION_DIAL)) }

    private fun safe(block: () -> Unit) {
        try { block() } catch (e: Exception) { toast("Not available on this device") }
    }
}
