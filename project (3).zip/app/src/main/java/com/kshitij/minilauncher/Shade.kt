package com.kshitij.minilauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationManager
import android.app.RemoteInput
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

/** Small hand-drawn glyphs for the Quick Settings tiles. */
class GlyphView(context: Context, private val kind: Int, private val color: Int) : View(context) {
    companion object {
        const val WIFI = 0
        const val BT = 1
        const val DATA = 2
        const val TORCH = 3
        const val DND = 4
        const val ROTATE = 5
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat()
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = s * 0.09f
        fun x(v: Float) = ox + v * s
        fun y(v: Float) = oy + v * s
        when (kind) {
            WIFI -> {
                val cx = x(0.5f)
                val cy = y(0.82f)
                for (r in floatArrayOf(0.46f, 0.31f, 0.16f)) {
                    c.drawArc(RectF(cx - r * s, cy - r * s, cx + r * s, cy + r * s), 225f, 90f, false, p)
                }
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, s * 0.04f, p)
            }
            BT -> {
                val path = Path()
                path.moveTo(x(0.30f), y(0.30f)); path.lineTo(x(0.70f), y(0.68f)); path.lineTo(x(0.50f), y(0.88f))
                path.lineTo(x(0.50f), y(0.12f)); path.lineTo(x(0.70f), y(0.32f)); path.lineTo(x(0.30f), y(0.70f))
                c.drawPath(path, p)
            }
            DATA -> {
                c.drawLine(x(0.34f), y(0.86f), x(0.34f), y(0.14f), p)
                c.drawLine(x(0.20f), y(0.30f), x(0.34f), y(0.14f), p)
                c.drawLine(x(0.48f), y(0.30f), x(0.34f), y(0.14f), p)
                c.drawLine(x(0.66f), y(0.14f), x(0.66f), y(0.86f), p)
                c.drawLine(x(0.52f), y(0.70f), x(0.66f), y(0.86f), p)
                c.drawLine(x(0.80f), y(0.70f), x(0.66f), y(0.86f), p)
            }
            TORCH -> {
                p.style = Paint.Style.FILL
                val path = Path()
                path.moveTo(x(0.58f), y(0.06f)); path.lineTo(x(0.26f), y(0.55f)); path.lineTo(x(0.47f), y(0.55f))
                path.lineTo(x(0.40f), y(0.94f)); path.lineTo(x(0.74f), y(0.42f)); path.lineTo(x(0.53f), y(0.42f))
                path.close()
                c.drawPath(path, p)
            }
            DND -> {
                c.drawCircle(x(0.5f), y(0.5f), s * 0.38f, p)
                c.drawLine(x(0.30f), y(0.5f), x(0.70f), y(0.5f), p)
            }
            ROTATE -> {
                val r = s * 0.34f
                c.drawArc(RectF(x(0.5f) - r, y(0.5f) - r, x(0.5f) + r, y(0.5f) + r), 40f, 270f, false, p)
                c.drawLine(x(0.76f), y(0.30f), x(0.76f), y(0.12f), p)
                c.drawLine(x(0.76f), y(0.30f), x(0.58f), y(0.30f), p)
            }
        }
    }
}

/**
 * In-launcher Quick Settings and notification panel. Android does not let a launcher restyle the
 * system shade, so this is our own panel: toggles that can be changed by an app are changed here,
 * the rest open the matching system panel.
 */
class Shade(
    private val act: Activity,
    private val ui: Ui,
    private val onClose: () -> Unit,
    private val onSystemShade: () -> Unit
) {
    val root = FrameLayout(act)
    private val tilesBox = LinearLayout(act)
    private val notifBox = LinearLayout(act)
    private val seek = SeekBar(act)
    private val brightHint = TextView(act)
    private val clearAll = TextView(act)

    private val cm = act.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val nm = act.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private var torchId: String? = null
    private var torchOn = false
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) {
                torchOn = enabled
                if (isVisible) rebuildTiles()
            }
        }
    }

    val isVisible: Boolean get() = root.visibility == View.VISIBLE

    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    init {
        try {
            for (id in cm.cameraIdList) {
                val flash = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE)
                if (flash == true) { torchId = id; break }
            }
            cm.registerTorchCallback(torchCb, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { /* no flashlight */ }

        root.setBackgroundColor(ui.pal.bg)
        root.isClickable = true   // swallow touches so the home screen underneath stays quiet
        root.visibility = View.GONE

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL

        // header with ribbons
        val header = FrameLayout(act)
        header.addView(SwooshView(act, SwooshView.HEADER_SHADE), FrameLayout.LayoutParams(-1, -1))
        val title = TextView(act)
        title.text = "Quick Settings"
        title.textSize = 22f
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.setTextColor(Color.WHITE)
        title.setPadding(ui.px(24), ui.px(20), 0, 0)
        header.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        val btns = LinearLayout(act)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.setPadding(0, ui.px(16), ui.px(16), 0)
        btns.addView(pill("System shade", Tally.withAlpha(Color.WHITE, 0x2A), Color.WHITE) { onSystemShade() })
        val sp = View(act)
        btns.addView(sp, LinearLayout.LayoutParams(ui.px(8), 1))
        btns.addView(pill("Close", Tally.GOLD, Tally.DEEP) { onClose() })
        header.addView(btns, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        col.addView(header, LinearLayout.LayoutParams(-1, ui.px(170)))

        // scrolling content
        val scroll = ScrollView(act)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        val content = LinearLayout(act)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(ui.px(15), 0, ui.px(15), ui.px(40))

        tilesBox.orientation = LinearLayout.VERTICAL
        content.addView(tilesBox)
        content.addView(brightnessCard())

        val nh = LinearLayout(act)
        nh.orientation = LinearLayout.HORIZONTAL
        nh.gravity = Gravity.CENTER_VERTICAL
        nh.setPadding(ui.px(8), ui.px(22), ui.px(8), 0)
        val nl = TextView(act)
        nl.text = "NOTIFICATIONS"
        nl.textSize = 12f
        nl.letterSpacing = 0.15f
        nl.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        nl.setTextColor(ui.pal.label)
        nh.addView(nl, LinearLayout.LayoutParams(0, -2, 1f))
        clearAll.text = "Clear all"
        clearAll.textSize = 13f
        clearAll.setTextColor(Tally.SKY)
        clearAll.setPadding(ui.px(10), ui.px(6), ui.px(10), ui.px(6))
        clearAll.setOnClickListener {
            try { LauncherNotificationService.instance?.cancelAllNotifications() } catch (e: Exception) { }
        }
        nh.addView(clearAll)
        content.addView(nh)
        content.addView(SwooshView(act, SwooshView.GOLD_DIV), LinearLayout.LayoutParams(-1, ui.px(16)))

        notifBox.orientation = LinearLayout.VERTICAL
        notifBox.setPadding(0, ui.px(8), 0, 0)
        content.addView(notifBox)

        val maxW = min(act.resources.configuration.screenWidthDp, 640)
        scroll.addView(content, FrameLayout.LayoutParams(ui.px(maxW), -2, Gravity.CENTER_HORIZONTAL))
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(col, FrameLayout.LayoutParams(-1, -1))
    }

    fun destroy() {
        try { cm.unregisterTorchCallback(torchCb) } catch (e: Exception) { }
    }

    fun show() {
        root.visibility = View.VISIBLE
        rebuildTiles()
        refreshBrightness()
        rebuildNotifs()
    }

    fun hide() { root.visibility = View.GONE }

    fun onResume() {
        if (isVisible) { rebuildTiles(); refreshBrightness(); rebuildNotifs() }
    }

    fun onNotificationsChanged() {
        if (isVisible) rebuildNotifs()
    }

    // ---------- helpers ----------

    private fun pill(text: String, fill: Int, fg: Int, onClick: () -> Unit): TextView {
        val t = TextView(act)
        t.text = text
        t.textSize = 13f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.setTextColor(fg)
        t.background = ui.cardBg(16, fill, fill, 0)
        t.setPadding(ui.px(14), ui.px(7), ui.px(14), ui.px(7))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun open(vararg actions: String): Boolean {
        for (a in actions) {
            try {
                act.startActivity(Intent(a))
                return true
            } catch (e: Exception) { }
        }
        toast("Not available on this device")
        return false
    }

    private fun requestWriteSettings() {
        try {
            act.startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + act.packageName))
            )
            toast("Allow \"Modify system settings\" for Mini Launcher")
        } catch (e: Exception) { toast("Not available on this device") }
    }

    // ---------- tiles ----------

    private fun tile(kind: Int, title: String, sub: String, active: Boolean, onClick: () -> Unit): View {
        val t = LinearLayout(act)
        t.orientation = LinearLayout.VERTICAL
        t.background = if (active) ui.cardBg(14, Tally.DEEP, Tally.DEEP, 0) else ui.cardBg(14)
        t.elevation = ui.pxf(2f)
        t.setPadding(ui.px(14), ui.px(12), ui.px(14), ui.px(10))
        t.isClickable = true
        t.setOnClickListener { onClick() }

        val fg = if (active) Color.WHITE else (if (ui.dark) ui.pal.text else Tally.DEEP)
        val subC = if (active) Color.parseColor("#CFE0FF") else ui.pal.sub

        val top = LinearLayout(act)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(GlyphView(act, kind, fg), LinearLayout.LayoutParams(ui.px(26), ui.px(26)))
        top.addView(View(act), LinearLayout.LayoutParams(0, 1, 1f))
        val ind = View(act)
        ind.background = ui.cardBg(3, if (active) Tally.GOLD else ui.pal.border, if (active) Tally.GOLD else ui.pal.border, 0)
        top.addView(ind, LinearLayout.LayoutParams(ui.px(22), ui.px(6)))
        t.addView(top)

        t.addView(View(act), LinearLayout.LayoutParams(1, 0, 1f))
        val tt = TextView(act)
        tt.text = title
        tt.textSize = 14f
        tt.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tt.setTextColor(fg)
        t.addView(tt)
        val st = TextView(act)
        st.text = sub
        st.textSize = 12f
        st.setTextColor(subC)
        t.addView(st)
        return t
    }

    @Suppress("DEPRECATION")
    private fun wifiOn(): Boolean = try {
        (act.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) { false }

    private fun btOn(): Boolean = try {
        (act.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true
    } catch (e: Exception) { false }

    private fun dndOn(): Boolean {
        val f = nm.currentInterruptionFilter
        return f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    private fun rotationOn(): Boolean = try {
        Settings.System.getInt(act.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 1
    } catch (e: Exception) { true }

    private fun rebuildTiles() {
        tilesBox.removeAllViews()
        val wifi = wifiOn()
        val bt = btOn()
        val dnd = dndOn()
        val rot = rotationOn()
        val items = ArrayList<View>()
        items.add(tile(GlyphView.WIFI, "Wi-Fi", if (wifi) "On \u00B7 tap to change" else "Off \u00B7 tap to change", wifi) {
            open(Settings.Panel.ACTION_WIFI, Settings.ACTION_WIFI_SETTINGS)
        })
        items.add(tile(GlyphView.BT, "Bluetooth", if (bt) "On \u00B7 tap to change" else "Off \u00B7 tap to change", bt) {
            open(Settings.ACTION_BLUETOOTH_SETTINGS)
        })
        items.add(tile(GlyphView.DATA, "Mobile data", "Tap to manage", false) {
            open(Settings.Panel.ACTION_INTERNET_CONNECTIVITY, Settings.ACTION_WIRELESS_SETTINGS)
        })
        items.add(tile(GlyphView.TORCH, "Flashlight", if (torchOn) "On" else "Off", torchOn) {
            val id = torchId
            if (id == null) toast("No flashlight on this device")
            else try { cm.setTorchMode(id, !torchOn) } catch (e: Exception) { toast("Flashlight unavailable") }
        })
        items.add(tile(GlyphView.DND, "Do not disturb", if (dnd) "On" else "Off", dnd) {
            if (!nm.isNotificationPolicyAccessGranted) {
                open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                toast("Allow Do Not Disturb access for Mini Launcher")
            } else {
                nm.setInterruptionFilter(
                    if (dnd) NotificationManager.INTERRUPTION_FILTER_ALL
                    else NotificationManager.INTERRUPTION_FILTER_PRIORITY
                )
                rebuildTiles()
            }
        })
        items.add(tile(GlyphView.ROTATE, "Auto-rotate", if (rot) "On" else "Off", rot) {
            if (!Settings.System.canWrite(act)) requestWriteSettings()
            else {
                try {
                    Settings.System.putInt(act.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (rot) 0 else 1)
                } catch (e: Exception) { toast("Could not change rotation") }
                rebuildTiles()
            }
        })

        val cols = if (act.resources.configuration.screenWidthDp >= 600) 3 else 2
        var row: LinearLayout? = null
        for ((i, v) in items.withIndex()) {
            if (i % cols == 0) {
                val r = LinearLayout(act)
                r.orientation = LinearLayout.HORIZONTAL
                val rlp = LinearLayout.LayoutParams(-1, -2)
                rlp.setMargins(0, 0, 0, ui.px(10))
                tilesBox.addView(r, rlp)
                row = r
            }
            val lp = LinearLayout.LayoutParams(0, ui.px(96), 1f)
            lp.setMargins(ui.px(5), 0, ui.px(5), 0)
            row?.addView(v, lp)
        }
        val rem = (cols - items.size % cols) % cols
        for (k in 0 until rem) {
            val lp = LinearLayout.LayoutParams(0, ui.px(96), 1f)
            lp.setMargins(ui.px(5), 0, ui.px(5), 0)
            row?.addView(View(act), lp)
        }
    }

    // ---------- brightness ----------

    private fun brightnessCard(): View {
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.background = ui.cardBg(14)
        card.elevation = ui.pxf(2f)
        card.setPadding(ui.px(16), ui.px(12), ui.px(16), ui.px(10))
        val l = TextView(act)
        l.text = "BRIGHTNESS"
        l.textSize = 11f
        l.letterSpacing = 0.14f
        l.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        l.setTextColor(ui.pal.sub)
        card.addView(l)

        seek.max = 255
        seek.progressTintList = ColorStateList.valueOf(Tally.GOLD)
        seek.thumbTintList = ColorStateList.valueOf(Tally.GOLD)
        seek.progressBackgroundTintList = ColorStateList.valueOf(ui.pal.border)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser && Settings.System.canWrite(act)) {
                    try {
                        Settings.System.putInt(
                            act.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                        )
                        Settings.System.putInt(act.contentResolver, Settings.System.SCREEN_BRIGHTNESS, max(p, 5))
                    } catch (e: Exception) { }
                }
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        seek.setOnTouchListener { _, e ->
            if (!Settings.System.canWrite(act)) {
                if (e.action == MotionEvent.ACTION_UP) requestWriteSettings()
                true
            } else false
        }
        card.addView(seek, LinearLayout.LayoutParams(-1, -2))

        brightHint.textSize = 12f
        brightHint.setTextColor(ui.pal.sub)
        card.addView(brightHint)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(ui.px(5), 0, ui.px(5), 0)
        card.layoutParams = lp
        return card
    }

    private fun refreshBrightness() {
        try {
            seek.progress = Settings.System.getInt(act.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        } catch (e: Exception) { }
        brightHint.text = if (Settings.System.canWrite(act)) "" else "Tap the slider to allow brightness control"
        brightHint.visibility = if (Settings.System.canWrite(act)) View.GONE else View.VISIBLE
    }

    // ---------- notifications ----------

    private fun appLabel(pkg: String): String = try {
        act.packageManager.getApplicationInfo(pkg, 0).loadLabel(act.packageManager).toString()
    } catch (e: Exception) { pkg.substringAfterLast('.') }

    private fun rebuildNotifs() {
        notifBox.removeAllViews()
        val svc = LauncherNotificationService.instance
        if (svc == null) {
            clearAll.visibility = View.GONE
            notifBox.addView(permissionCard())
            return
        }
        clearAll.visibility = View.VISIBLE
        val all: Array<StatusBarNotification> = try { svc.activeNotifications ?: emptyArray() } catch (e: Exception) { emptyArray() }
        val list = all
            .filter { it.packageName != act.packageName && (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
            .sortedByDescending { it.postTime }
        if (list.isEmpty()) {
            val t = TextView(act)
            t.text = "You're all caught up."
            t.textSize = 14f
            t.setTextColor(ui.pal.sub)
            t.setPadding(ui.px(8), ui.px(12), 0, 0)
            notifBox.addView(t)
            return
        }
        for (sbn in list) notifBox.addView(notifCard(sbn, svc))
    }

    private fun permissionCard(): View {
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.background = ui.cardBg(14)
        c.setPadding(ui.px(18), ui.px(16), ui.px(18), ui.px(16))
        val h = TextView(act)
        h.text = "Show notifications here"
        h.textSize = 16f
        h.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        h.setTextColor(ui.pal.text)
        c.addView(h)
        val b = TextView(act)
        b.text = "Turn on notification access for Mini Launcher to see, dismiss and reply to notifications in this panel. " +
            "They stay on this device: the launcher has no internet permission and stores nothing. " +
            "You can switch access off any time in system settings."
        b.textSize = 13f
        b.setTextColor(ui.pal.sub)
        b.setPadding(0, ui.px(6), 0, ui.px(12))
        c.addView(b)
        c.addView(pill("Enable notification access", Tally.GOLD, Tally.DEEP) {
            open(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        })
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(ui.px(5), ui.px(6), ui.px(5), 0)
        c.layoutParams = lp
        return c
    }

    private fun findReplyAction(n: Notification): Notification.Action? {
        val acts = n.actions ?: return null
        for (a in acts) {
            val ri = a.remoteInputs
            if (ri != null && ri.isNotEmpty() && a.actionIntent != null) return a
        }
        return null
    }

    private fun askReply(a: Notification.Action, who: String) {
        val input = EditText(act)
        input.hint = "Reply to $who"
        input.setSingleLine(false)
        val theme = if (ui.dark) AlertDialog.THEME_DEVICE_DEFAULT_DARK else AlertDialog.THEME_DEVICE_DEFAULT_LIGHT
        AlertDialog.Builder(act, theme)
            .setTitle("Reply")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Send") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) sendReply(a, text)
            }
            .show()
    }

    private fun sendReply(a: Notification.Action, text: String) {
        try {
            val ri = a.remoteInputs ?: return
            val intent = Intent()
            val b = Bundle()
            for (r in ri) b.putCharSequence(r.resultKey, text)
            RemoteInput.addResultsToIntent(ri, intent, b)
            a.actionIntent.send(act, 0, intent)
        } catch (e: Exception) { toast("Could not send reply") }
    }

    private fun notifCard(sbn: StatusBarNotification, svc: LauncherNotificationService): View {
        val n = sbn.notification
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        val full = if (!big.isNullOrEmpty()) big else text
        val accent = when (n.category) {
            Notification.CATEGORY_MESSAGE, Notification.CATEGORY_EMAIL -> Tally.SKY
            Notification.CATEGORY_CALL, Notification.CATEGORY_ALARM, Notification.CATEGORY_ERROR -> Tally.CORAL
            Notification.CATEGORY_PROGRESS, Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM, Notification.CATEGORY_STATUS -> Tally.TEAL
            else -> Tally.GOLD
        }
        val app = appLabel(sbn.packageName)

        val card = LinearLayout(act)
        card.orientation = LinearLayout.HORIZONTAL
        card.background = ui.cardBg(12)
        card.elevation = ui.pxf(1f)
        val clp = LinearLayout.LayoutParams(-1, -2)
        clp.setMargins(ui.px(5), ui.px(5), ui.px(5), ui.px(5))
        card.layoutParams = clp

        val bar = View(act)
        bar.background = ui.cardBg(3, accent, accent, 0)
        val blp = LinearLayout.LayoutParams(ui.px(5), -1)
        blp.setMargins(ui.px(8), ui.px(10), 0, ui.px(10))
        card.addView(bar, blp)

        val body = LinearLayout(act)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(ui.px(12), ui.px(10), ui.px(6), ui.px(10))

        val appT = TextView(act)
        appT.text = app.uppercase()
        appT.textSize = 10f
        appT.letterSpacing = 0.12f
        appT.setTextColor(ui.pal.sub)
        body.addView(appT)

        val titleT = TextView(act)
        titleT.text = title
        titleT.textSize = 15f
        titleT.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        titleT.setTextColor(ui.pal.text)
        titleT.maxLines = 1
        titleT.ellipsize = TextUtils.TruncateAt.END
        body.addView(titleT)

        val msg = TextView(act)
        msg.text = text
        msg.textSize = 13f
        msg.setTextColor(ui.pal.sub)
        msg.maxLines = 2
        msg.ellipsize = TextUtils.TruncateAt.END
        body.addView(msg)

        val actions = LinearLayout(act)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.setPadding(0, ui.px(10), 0, 0)
        actions.visibility = View.GONE
        val spacerLp = { LinearLayout.LayoutParams(ui.px(8), 1) }
        if (n.contentIntent != null) {
            actions.addView(pill("Open", Tally.DEEP, Color.WHITE) {
                try { n.contentIntent.send() } catch (e: Exception) { toast("Could not open") }
                onClose()
            })
            actions.addView(View(act), spacerLp())
        }
        val reply = findReplyAction(n)
        if (reply != null) {
            actions.addView(pill("Reply", Tally.GOLD, Tally.DEEP) { askReply(reply, title) })
        }
        body.addView(actions)

        var expanded = false
        card.setOnClickListener {
            expanded = !expanded
            msg.maxLines = if (expanded) 12 else 2
            msg.text = if (expanded) full else text
            actions.visibility = if (expanded && actions.childCount > 0) View.VISIBLE else View.GONE
        }
        card.addView(body, LinearLayout.LayoutParams(0, -2, 1f))

        if (sbn.isClearable) {
            val x = TextView(act)
            x.text = "\u2715"
            x.textSize = 16f
            x.setTextColor(ui.pal.sub)
            x.gravity = Gravity.CENTER
            x.setPadding(ui.px(14), ui.px(8), ui.px(14), ui.px(8))
            x.setOnClickListener {
                try { svc.cancelNotification(sbn.key) } catch (e: Exception) { }
            }
            val xlp = LinearLayout.LayoutParams(-2, -2)
            xlp.gravity = Gravity.TOP
            card.addView(x, xlp)
        }
        return card
    }
}
