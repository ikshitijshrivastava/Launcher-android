package com.kshitij.minilauncher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Optional: only receives notifications after the user turns on notification access for this app
 * in system settings. Nothing is stored; the launcher reads the active list on demand.
 */
class LauncherNotificationService : NotificationListenerService() {

    companion object {
        @Volatile var instance: LauncherNotificationService? = null
        @Volatile var onChange: (() -> Unit)? = null
    }

    override fun onListenerConnected() {
        instance = this
        onChange?.invoke()
    }

    override fun onListenerDisconnected() {
        instance = null
        onChange?.invoke()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        onChange?.invoke()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        onChange?.invoke()
    }
}
