package com.kshitij.minilauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/**
 * Lightweight vector swooshes drawn with Canvas. Paths are built once in onSizeChanged,
 * onDraw only draws them, so there is no allocation while scrolling or launching.
 */
class SwooshView(context: Context, private val kind: Int) : View(context) {

    companion object {
        const val HOME = 0      // big navy header with sky / teal / gold layers
        const val DRAWER = 1    // navy header with teal / sky layers
        const val GOLD_DIV = 2  // thin gold + coral curved divider (favourites)
        const val TEAL_DIV = 3  // thin teal + sky curved divider (app groups)
        const val CORNER = 4    // soft bottom-corner accent
    }

    private val d = resources.displayMetrics.density
    private val paths = ArrayList<Path>()
    private val paints = ArrayList<Paint>()

    private fun fill(color: Int, alpha: Int = 255): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        p.color = color
        p.alpha = alpha
        return p
    }

    private fun stroke(color: Int, widthDp: Float, alpha: Int = 255): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = widthDp * d
        p.color = color
        p.alpha = alpha
        return p
    }

    private fun add(path: Path, paint: Paint) {
        paths.add(path)
        paints.add(paint)
    }

    /** Filled area from the top edge down to an S-shaped curve. */
    private fun curtain(w: Float, h: Float, offL: Float, offR: Float): Path {
        val p = Path()
        p.moveTo(0f, 0f)
        p.lineTo(w, 0f)
        p.lineTo(w, h * 0.70f + offR)
        p.cubicTo(
            w * 0.68f, h * 0.90f + offR * 1.6f,
            w * 0.34f, h * 0.52f + offL * 0.4f,
            0f, h * 0.78f + offL
        )
        p.close()
        return p
    }

    /** Filled wedge rising from the bottom-left of the view up to the right edge. */
    private fun wedge(w: Float, h: Float, c1y: Float, c2y: Float, yRight: Float): Path {
        val p = Path()
        p.moveTo(0f, h)
        p.cubicTo(w * 0.35f, c1y, w * 0.70f, c2y, w, yRight)
        p.lineTo(w, h)
        p.close()
        return p
    }

    private fun line(
        w: Float, h: Float, y0: Float, c1y: Float, c2y: Float, y1: Float,
        x0: Float = 2f * d, x1: Float = w - 2f * d
    ): Path {
        val p = Path()
        p.moveTo(x0, y0)
        p.cubicTo(w * 0.30f, c1y, w * 0.65f, c2y, x1, y1)
        return p
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        paths.clear()
        paints.clear()
        val fw = w.toFloat()
        val fh = h.toFloat()
        when (kind) {
            HOME -> {
                add(curtain(fw, fh, fh * 0.115f, fh * 0.055f), fill(Tally.GOLD))
                add(curtain(fw, fh, fh * 0.085f, fh * 0.040f), fill(Tally.TEAL))
                add(curtain(fw, fh, fh * 0.050f, fh * 0.022f), fill(Tally.SKY))
                add(curtain(fw, fh, 0f, 0f), fill(Tally.NAVY))
            }
            DRAWER -> {
                add(curtain(fw, fh, fh * 0.100f, fh * 0.050f), fill(Tally.TEAL))
                add(curtain(fw, fh, fh * 0.050f, fh * 0.022f), fill(Tally.SKY))
                add(curtain(fw, fh, 0f, 0f), fill(Tally.NAVY))
            }
            GOLD_DIV -> {
                add(line(fw, fh, fh * 0.65f, fh * 0.20f, fh * 0.90f, fh * 0.35f), stroke(Tally.GOLD, 3f))
                add(line(fw, fh, fh * 0.80f, fh * 0.40f, fh * 0.95f, fh * 0.65f, 2f * d, fw * 0.8f), stroke(Tally.CORAL, 1.5f, 210))
            }
            TEAL_DIV -> {
                add(line(fw, fh, fh * 0.60f, fh * 0.15f, fh * 0.90f, fh * 0.40f), stroke(Tally.TEAL, 2f))
                add(line(fw, fh, fh * 0.75f, fh * 0.35f, fh * 0.95f, fh * 0.60f, 2f * d, fw * 0.6f), stroke(Tally.SKY, 1f, 200))
            }
            CORNER -> {
                add(wedge(fw, fh, fh * 0.55f, fh * 0.28f, fh * 0.12f), fill(Tally.CORAL, 0x40))
                add(wedge(fw, fh, fh * 0.72f, fh * 0.45f, fh * 0.30f), fill(Tally.TEAL, 0x55))
                add(wedge(fw, fh, fh * 0.85f, fh * 0.65f, fh * 0.50f), fill(Tally.SKY, 0x66))
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        for (i in 0 until paths.size) canvas.drawPath(paths[i], paints[i])
    }
}

/** Small crisp magnifier icon for the Go To search bar. */
class SearchIconView(context: Context, color: Int) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.color = color
    }

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height).toFloat()
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        p.strokeWidth = s * 0.11f
        val r = s * 0.30f
        val cx = ox + s * 0.42f
        val cy = oy + s * 0.42f
        canvas.drawCircle(cx, cy, r, p)
        canvas.drawLine(cx + r * 0.72f, cy + r * 0.72f, ox + s * 0.88f, oy + s * 0.88f, p)
    }
}
