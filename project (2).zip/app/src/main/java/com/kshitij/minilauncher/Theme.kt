package com.kshitij.minilauncher

import android.graphics.Color

/** TallyPrime-inspired colour tokens. Light and dark palettes are chosen at runtime. */
object Tally {
    val NAVY: Int = Color.parseColor("#0B3B8C")
    val SKY: Int = Color.parseColor("#2B7DE9")
    val GOLD: Int = Color.parseColor("#F7B500")
    val TEAL: Int = Color.parseColor("#00A88F")
    val CORAL: Int = Color.parseColor("#F26522")

    class Palette(
        val bg: Int,        // main canvas
        val surface: Int,   // cards / search bar
        val text: Int,      // primary text
        val sub: Int,       // secondary text
        val label: Int,     // small section labels
        val onHeader: Int,  // text drawn on the navy header
        val onHeaderSub: Int
    )

    fun palette(dark: Boolean): Palette =
        if (dark) Palette(
            bg = Color.parseColor("#0A1628"),
            surface = Color.parseColor("#13233D"),
            text = Color.parseColor("#E8F1FF"),
            sub = Color.parseColor("#8FA8CC"),
            label = GOLD,
            onHeader = Color.WHITE,
            onHeaderSub = Color.parseColor("#BFD4F5")
        ) else Palette(
            bg = Color.parseColor("#F4F7FC"),
            surface = Color.parseColor("#FFFFFF"),
            text = Color.parseColor("#1E293B"),
            sub = Color.parseColor("#64748B"),
            label = NAVY,
            onHeader = Color.WHITE,
            onHeaderSub = Color.parseColor("#CFE0FF")
        )

    fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)
}
