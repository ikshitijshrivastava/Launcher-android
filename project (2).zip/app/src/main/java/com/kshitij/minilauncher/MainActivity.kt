package com.kshitij.minilauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class AppItem(val label: String, val pkg: String, val cls: String)

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var pal: Tally.Palette
    private var dark = false

    private var allApps: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()   // apps matching the search
    private var rows: List<Any> = emptyList()        // String = letter header, AppItem = app

    private lateinit var home: FrameLayout
    private lateinit var favBox: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var list: ListView
    private lateinit var adapter: BaseAdapter
    private lateinit var gestures: GestureDetector

    private val autoLaunch: Boolean get() = prefs.getBoolean("auto", false)
    private fun px(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun isDark(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        dark = isDark()
        pal = Tally.palette(dark)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        val root = FrameLayout(this)
        root.setBackgroundColor(pal.bg)
        buildHome()
        buildDrawer()
        root.addView(home, FrameLayout.LayoutParams(-1, -1))
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
        drawer.visibility = View.GONE
        setContentView(root)
        applySystemBars()

        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || drawer.visibility == View.VISIBLE) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                val min = px(80)
                if (abs(dy) > abs(dx)) {
                    if (dy < -min) openDrawer() else if (dy > min) expandNotifications()
                } else {
                    if (dx < -min) openCamera() else if (dx > min) openDialer()
                }
                return true
            }
        })
        gestures.setIsLongpressEnabled(false)
    }

    @Suppress("DEPRECATION")
    private fun applySystemBars() {
        window.statusBarColor = Tally.NAVY
        window.navigationBarColor = pal.bg
        if (!dark) {
            val v = window.decorView
            v.systemUiVisibility = v.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (isDark() != dark) recreate()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        refreshFavs()
        filter()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        closeDrawer()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (drawer.visibility == View.VISIBLE) closeDrawer()
    }

    // ---------- Shared drawables ----------

    /** TallyPrime-style highlight: soft gold pill with a gold bar on the left. */
    private fun highlight(): LayerDrawable {
        val fill = GradientDrawable()
        fill.setColor(Tally.withAlpha(Tally.GOLD, 0x2E))
        fill.cornerRadius = px(8).toFloat()
        val bar = GradientDrawable()
        bar.setColor(Tally.GOLD)
        bar.cornerRadius = px(2).toFloat()
        val ld = LayerDrawable(arrayOf<Drawable>(fill, bar))
        ld.setLayerWidth(1, px(4))
        ld.setLayerGravity(1, Gravity.START or Gravity.FILL_VERTICAL)
        ld.setLayerInsetTop(1, px(7))
        ld.setLayerInsetBottom(1, px(7))
        return ld
    }

    private fun stateHighlight(): StateListDrawable {
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_pressed), highlight())
        s.addState(intArrayOf(android.R.attr.state_focused), highlight())
        s.addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
        return s
    }

    // ---------- Home ----------

    private fun buildHome() {
        home = FrameLayout(this)

        val corner = SwooshView(this, SwooshView.CORNER)
        home.addView(corner, FrameLayout.LayoutParams(px(180), px(140), Gravity.BOTTOM or Gravity.END))

        val header = SwooshView(this, SwooshView.HOME)
        header.setOnLongClickListener { showSettings(); true }
        home.addView(header, FrameLayout.LayoutParams(-1, px(230), Gravity.TOP))

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(px(28), px(24), px(28), px(44))

        val clock = TextClock(this)
        clock.format12Hour = "h:mm"
        clock.format24Hour = "HH:mm"
        clock.textSize = 56f
        clock.setTextColor(pal.onHeader)
        clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)

        val date = TextClock(this)
        date.format12Hour = "EEEE, d MMMM"
        date.format24Hour = "EEEE, d MMMM"
        date.textSize = 15f
        date.setTextColor(pal.onHeaderSub)

        val spacer = View(this)
        spacer.setOnLongClickListener { showSettings(); true }

        val label = TextView(this)
        label.text = "PINNED"
        label.textSize = 12f
        label.letterSpacing = 0.15f
        label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        label.setTextColor(pal.label)
        label.setPadding(px(16), 0, 0, 0)

        val divider = SwooshView(this, SwooshView.GOLD_DIV)

        favBox = LinearLayout(this)
        favBox.orientation = LinearLayout.VERTICAL

        content.addView(clock)
        content.addView(date)
        content.addView(spacer, LinearLayout.LayoutParams(-1, 0, 1f))
        content.addView(label)
        content.addView(divider, LinearLayout.LayoutParams(-1, px(14)))
        content.addView(favBox)
        home.addView(content, FrameLayout.LayoutParams(-1, -1))

        // Tiny, non-prominent signature in the bottom-left corner.
        val sig = TextView(this)
        sig.text = "Kshitij"
        sig.textSize = 9f
        sig.letterSpacing = 0.12f
        sig.setTextColor(Tally.withAlpha(pal.sub, 110))
        val sigLp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START)
        sigLp.setMargins(px(14), 0, 0, px(10))
        home.addView(sig, sigLp)
    }

    private fun refreshFavs() {
        favBox.removeAllViews()
        val favs = getFavs().mapNotNull { p -> allApps.firstOrNull { it.pkg == p } }
        if (favs.isEmpty()) {
            val hint = TextView(this)
            hint.text = "Swipe up for all apps. Long-press an app to pin it here.\nLong-press empty space for settings and to switch back to your old launcher."
            hint.setTextColor(pal.sub)
            hint.textSize = 14f
            hint.setPadding(px(16), px(8), 0, 0)
            favBox.addView(hint)
        }
        for (a in favs) {
            val t = TextView(this)
            t.text = a.label
            t.textSize = 26f
            t.setTextColor(pal.text)
            t.setPadding(px(16), px(11), px(12), px(11))
            t.background = stateHighlight()
            t.isFocusable = true
            t.setOnClickListener { launch(a) }
            t.setOnLongClickListener { showAppMenu(a); true }
            favBox.addView(t)
        }
    }

    // ---------- Drawer ----------

    private fun buildDrawer() {
        drawer = LinearLayout(this)
        drawer.orientation = LinearLayout.VERTICAL
        drawer.setBackgroundColor(pal.bg)

        // Header: teal / sky swooshes with the "Go To" search bar on the curve edge
        val headerHolder = FrameLayout(this)
        headerHolder.addView(SwooshView(this, SwooshView.DRAWER), FrameLayout.LayoutParams(-1, -1))

        val title = TextView(this)
        title.text = "All Apps"
        title.textSize = 18f
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.setTextColor(pal.onHeader)
        title.setPadding(px(28), px(20), 0, 0)
        headerHolder.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(px(14), 0, px(12), 0)
        val barBg = GradientDrawable()
        barBg.setColor(pal.surface)
        barBg.cornerRadius = px(12).toFloat()
        barBg.setStroke(px(2), Tally.SKY)
        bar.background = barBg
        bar.elevation = px(4).toFloat()

        val icon = SearchIconView(this, Tally.SKY)
        bar.addView(icon, LinearLayout.LayoutParams(px(20), px(20)))

        search = EditText(this)
        search.hint = "Go To  \u2013  type an app name"
        search.setHintTextColor(pal.sub)
        search.setTextColor(pal.text)
        search.textSize = 18f
        search.setSingleLine(true)
        search.background = null
        search.setPadding(px(10), 0, 0, 0)
        search.imeOptions = EditorInfo.IME_ACTION_GO
        search.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter() }
        })
        search.setOnEditorActionListener { _, _, _ ->
            if (shown.isNotEmpty()) launch(shown[0])
            true
        }
        bar.addView(search, LinearLayout.LayoutParams(0, -1, 1f))

        val barLp = FrameLayout.LayoutParams(-1, px(52), Gravity.BOTTOM)
        barLp.setMargins(px(24), 0, px(24), px(18))
        headerHolder.addView(bar, barLp)

        list = ListView(this)
        list.divider = null
        list.overScrollMode = View.OVER_SCROLL_NEVER
        list.selector = highlight()
        list.setDrawSelectorOnTop(false)
        list.setPadding(px(24), px(8), px(24), px(8))
        list.clipToPadding = false

        adapter = object : BaseAdapter() {
            override fun getCount(): Int = rows.size
            override fun getItem(i: Int): Any = rows[i]
            override fun getItemId(i: Int): Long = i.toLong()
            override fun getViewTypeCount(): Int = 2
            override fun getItemViewType(i: Int): Int = if (rows[i] is String) 0 else 1
            override fun areAllItemsEnabled(): Boolean = false
            override fun isEnabled(i: Int): Boolean = rows[i] is AppItem
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val r = rows[i]
                if (r is String) {
                    val box = (v as? LinearLayout) ?: buildLetterRow()
                    (box.getChildAt(0) as TextView).text = r
                    return box
                }
                val a = r as AppItem
                val t = (v as? TextView) ?: TextView(this@MainActivity).apply {
                    textSize = 20f
                    setTextColor(pal.text)
                    setPadding(px(16), px(13), px(12), px(13))
                }
                t.text = a.label
                return t
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, i, _ ->
            val r = rows[i]
            if (r is AppItem) launch(r)
        }
        list.setOnItemLongClickListener { _, _, i, _ ->
            val r = rows[i]
            if (r is AppItem) showAppMenu(r)
            true
        }

        drawer.addView(headerHolder, LinearLayout.LayoutParams(-1, px(176)))
        drawer.addView(list, LinearLayout.LayoutParams(-1, -1))
    }

    private fun buildLetterRow(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(px(4), px(14), px(4), 0)
        val t = TextView(this)
        t.textSize = 13f
        t.letterSpacing = 0.1f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        t.setTextColor(Tally.TEAL)
        t.setPadding(px(12), 0, 0, px(2))
        box.addView(t)
        box.addView(SwooshView(this, SwooshView.TEAL_DIV), LinearLayout.LayoutParams(-1, px(10)))
        return box
    }

    // ---------- Apps ----------

    private fun loadApps() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = packageManager.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppItem(
                    it.loadLabel(packageManager).toString(),
                    it.activityInfo.packageName,
                    it.activityInfo.name
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun matches(label: String, q: String): Boolean {
        if (label.contains(q)) return true
        var i = 0
        for (c in label) {
            if (i < q.length && c == q[i]) i++
        }
        return i == q.length
    }

    private fun group(apps: List<AppItem>): List<Any> {
        val out = ArrayList<Any>()
        var last = ""
        for (a in apps) {
            val c = a.label.trim().firstOrNull()?.uppercaseChar()
            val key = if (c != null && c.isLetter()) c.toString() else "#"
            if (key != last) {
                out.add(key)
                last = key
            }
            out.add(a)
        }
        return out
    }

    private fun filter() {
        val q = search.text.toString().trim().lowercase()
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        val base = allApps.filter { it.pkg !in hidden }
        shown = if (q.isEmpty()) base
        else base.filter { matches(it.label.lowercase(), q) }
            .sortedBy { if (it.label.lowercase().startsWith(q)) 0 else 1 }
        rows = if (q.isEmpty()) group(shown) else shown
        adapter.notifyDataSetChanged()
        if (autoLaunch && q.length >= 2 && shown.size == 1) launch(shown[0])
    }

    private fun launch(a: AppItem) {
        try {
            val i = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(a.pkg, a.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(i)
        } catch (e: Exception) {
            toast("Can't open ${a.label}")
        }
        closeDrawer()
    }

    private fun getFavs(): List<String> =
        (prefs.getString("favs", "") ?: "").split("\n").filter { it.isNotEmpty() }

    private fun setFavs(l: List<String>) {
        prefs.edit().putString("favs", l.joinToString("\n")).apply()
    }

    @Suppress("DEPRECATION")
    private fun dialogTheme(): Int =
        if (dark) AlertDialog.THEME_DEVICE_DEFAULT_DARK else AlertDialog.THEME_DEVICE_DEFAULT_LIGHT

    private fun showAppMenu(a: AppItem) {
        val isFav = a.pkg in getFavs()
        val items = arrayOf(
            if (isFav) "Remove from home" else "Pin to home",
            "Hide",
            "App info",
            "Uninstall"
        )
        AlertDialog.Builder(this, dialogTheme())
            .setTitle(a.label)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        val f = getFavs().toMutableList()
                        if (isFav) f.remove(a.pkg)
                        else if (f.size >= 8) toast("Home is full (8 apps)")
                        else f.add(a.pkg)
                        setFavs(f)
                    }
                    1 -> {
                        val s = HashSet(prefs.getStringSet("hidden", emptySet()) ?: emptySet())
                        s.add(a.pkg)
                        prefs.edit().putStringSet("hidden", s).apply()
                        setFavs(getFavs().filter { it != a.pkg })
                        toast("Hidden. Unhide from the home long-press menu.")
                    }
                    2 -> safe {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
                        )
                    }
                    3 -> safe {
                        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                    }
                }
                refreshFavs()
                filter()
            }
            .show()
    }

    private fun showSettings() {
        val items = arrayOf(
            "Switch back to default launcher",
            "Auto-open single search match: " + (if (autoLaunch) "ON" else "OFF"),
            "Unhide all apps",
            "System settings"
        )
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("Mini Launcher")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> switchLauncher()
                    1 -> prefs.edit().putBoolean("auto", !autoLaunch).apply()
                    2 -> { prefs.edit().remove("hidden").apply(); filter() }
                    3 -> safe { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                }
            }
            .show()
    }

    private fun switchLauncher() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                Toast.makeText(
                    this,
                    "Open Apps > Default apps > Home app and pick your old launcher",
                    Toast.LENGTH_LONG
                ).show()
            } catch (e2: Exception) {
                toast("Open Settings > Apps > Default apps > Home app")
            }
        }
    }

    // ---------- Drawer + gestures ----------

    private fun openDrawer() {
        drawer.visibility = View.VISIBLE
        search.requestFocus()
        search.post {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closeDrawer() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.setText("")
        drawer.visibility = View.GONE
    }

    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager")
                .getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) {
            toast("Pull down from the top edge")
        }
    }

    private fun openCamera() = safe { startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
    private fun openDialer() = safe { startActivity(Intent(Intent.ACTION_DIAL)) }

    private fun safe(block: () -> Unit) {
        try { block() } catch (e: Exception) { toast("Not available on this device") }
    }
}
