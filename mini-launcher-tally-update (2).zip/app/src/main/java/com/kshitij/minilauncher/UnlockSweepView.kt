package com.kshitij.minilauncher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * Brand-colour swoosh that sweeps across the Home screen after unlock. It crosses from a different
 * edge on each play (left, top, right, bottom in turn), moves slowly and at a steady pace, and fades
 * in and out. The view never takes touches, so the launcher underneath works normally.
 * Lock-screen drawing is not possible for third-party apps, so this plays on the launcher.
 */
class UnlockSweepView(context: Context) : View(context) {

    private var progress = 0f
    private var turn = 0
    private var animator: ValueAnimator? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    /** Each entry: colour, stroke width in dp, and a Bezier in unit coordinates (0..1 of the view). */
    private val strokes = listOf(
        Stroke(Tally.CYAN, 2.5f, 0xE6, floatArrayOf(0.00f, 0.80f, 0.30f, 0.40f, 0.70f, 0.95f, 1.00f, 0.50f)),
        Stroke(Tally.BLUE, 3f, 0xE6, floatArrayOf(0.00f, 0.30f, 0.40f, 0.60f, 0.60f, 0.20f, 1.00f, 0.80f)),
        Stroke(Tally.RED, 4f, 0xFF, floatArrayOf(0.00f, 0.95f, 0.35f, 0.25f, 0.65f, 0.80f, 1.00f, 0.15f))
    )

    private class Stroke(val color: Int, val widthDp: Float, val alpha: Int, val c: FloatArray)

    /** Direction of travel for the current play: the sweep enters from this edge. */
    private fun dirFor(t: Int): Pair<Float, Float> = when (t % 4) {
        0 -> -1f to 0f   // from left
        1 -> 0f to -1f   // from top
        2 -> 1f to 0f    // from right
        else -> 0f to 1f // from bottom
    }

    fun play(durationMs: Long = 2400L) {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = LinearInterpolator()   // steady pace, no easing
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    progress = 0f
                    invalidate()
                }
            })
            start()
        }
        turn++
    }

    fun cancelPlay() {
        animator?.cancel()
        progress = 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (progress <= 0f || progress >= 1f) return
        val w = width.toFloat()
        val h = height.toFloat()
        val (dx, dy) = dirFor(turn - 1)
        // travel distance: the sweep starts fully off the edge it enters from and ends off the far side
        val travelX = dx * w * 1.4f * (1f - progress)
        val travelY = dy * h * 1.4f * (1f - progress)
        // alpha rises for the first third and falls for the last third, so it never pops in or out
        val fade = when {
            progress < 0.33f -> progress / 0.33f
            progress > 0.66f -> (1f - progress) / 0.34f
            else -> 1f
        }
        val density = resources.displayMetrics.density
        for (s in strokes) {
            val p = Path()
            p.moveTo(w * s.c[0] + travelX, h * s.c[1] + travelY)
            p.cubicTo(
                w * s.c[2] + travelX, h * s.c[3] + travelY,
                w * s.c[4] + travelX, h * s.c[5] + travelY,
                w * s.c[6] + travelX, h * s.c[7] + travelY
            )
            paint.color = s.color
            paint.alpha = (s.alpha * fade).toInt()
            paint.strokeWidth = s.widthDp * density
            canvas.drawPath(p, paint)
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }
}
