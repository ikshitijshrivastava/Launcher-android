package com.kshitij.minilauncher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Draws every app icon inside the same Tally-themed squircle container.
 *  - apps with a monochrome (themed) icon layer: glyph tinted in the Tally palette
 *  - everything else: the normal icon, framed inside the same squircle
 *  - pinned apps get a gold border
 * Icons are rendered lazily on one background thread and kept in a small LRU cache.
 */
class IconProvider(private val ctx: Context, private val ui: Ui, sizeDp: Int = 44) {

    private val size = ui.px(sizeDp)
    private val cache = LruCache<String, Bitmap>(120)
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun bind(iv: ImageView, a: AppItem, pinned: Boolean) {
        val key = a.pkg + "/" + a.cls + (if (pinned) "#p" else "")
        iv.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        exec.execute {
            if (iv.tag != key) return@execute
            val bmp = try { render(a, pinned) } catch (e: Throwable) { null }
            if (bmp != null) {
                cache.put(key, bmp)
                main.post { if (iv.tag == key) iv.setImageBitmap(bmp) }
            }
        }
    }

    private fun place(d: Drawable, c: Canvas, scale: Float) {
        val l = (size * scale).toInt()
        val off = (size - l) / 2
        d.setBounds(off, off, off + l, off + l)
        d.draw(c)
    }

    private fun render(a: AppItem, pinned: Boolean): Bitmap {
        val s = size.toFloat()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val r = s * 0.30f
        val strokeW = if (pinned) ui.pxf(2f) else ui.pxf(1f)

        // squircle container
        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        bg.color = ui.pal.surface
        c.drawRoundRect(RectF(0f, 0f, s, s), r, r, bg)

        // icon, clipped to the container
        val clip = Path()
        clip.addRoundRect(RectF(0f, 0f, s, s), r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        val d: Drawable? = try {
            ctx.packageManager.getActivityIcon(ComponentName(a.pkg, a.cls))
        } catch (e: Exception) { null }
        if (d != null) {
            val tint = ui.pal.tints[abs(a.pkg.hashCode()) % ui.pal.tints.size]
            if (d is AdaptiveIconDrawable) {
                val mono = if (Build.VERSION.SDK_INT >= 33) d.monochrome else null
                if (mono != null) {
                    val m = mono.mutate()
                    m.setTint(tint)
                    place(m, c, 1.05f)
                } else {
                    place(d, c, 1.05f)
                }
            } else {
                place(d, c, 0.68f)
            }
        }
        c.restore()

        // border
        val st = Paint(Paint.ANTI_ALIAS_FLAG)
        st.style = Paint.Style.STROKE
        st.strokeWidth = strokeW
        st.color = if (pinned) Tally.BLUE else ui.pal.border
        val half = strokeW / 2f
        c.drawRoundRect(RectF(half, half, s - half, s - half), r, r, st)
        return bmp
    }
}
