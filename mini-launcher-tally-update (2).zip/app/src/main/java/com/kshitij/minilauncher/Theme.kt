package com.kshitij.minilauncher

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity

/**
 * Brand colour tokens. Hex values are the exact palette from the brand brief.
 * RED is reserved for rare accents only: the swoosh stroke, critical alerts and active badges.
 */
object Tally {
    // Background and surface tints
    val CREAM: Int = Color.parseColor("#FFFBE5")     // primary canvas
    val BLUSH: Int = Color.parseColor("#FEE7DC")     // soft coral / blush surface
    val MINT: Int = Color.parseColor("#B4FCF8")      // soft aqua / mint surface
    val SKY_TINT: Int = Color.parseColor("#A2DBF4")  // soft sky blue surface

    // Ink and accents
    val INK: Int = Color.parseColor("#000000")       // primary text
    val CYAN: Int = Color.parseColor("#00C9C2")      // vibrant cyan / teal
    val BLUE: Int = Color.parseColor("#0093FF")      // vibrant electric blue
    val RED: Int = Color.parseColor("#EC2027")       // signature red: rare, high-impact only

    /** Set by [Ui] so decorative views can pick the light or dark variant without a Context. */
    @JvmStatic var dark: Boolean = false

    /** Header band colour: sky tint in light mode, a translucent blue wash in dark mode. */
    fun headerBody(): Int = if (dark) withAlpha(BLUE, 0x33) else SKY_TINT

    /** Icon tints cycled per app (also used for grid and paged squircle cells). */
    fun cellTints(): IntArray = if (dark) intArrayOf(CYAN, BLUE, MINT, BLUSH)
    else intArrayOf(MINT, SKY_TINT, BLUSH)

    class Palette(
        val bg: Int,
        val surface: Int,
        val text: Int,
        val sub: Int,
        val label: Int,
        val onHeader: Int,
        val onHeaderSub: Int,
        val border: Int,
        val tints: IntArray   // icon tints cycled per app
    )

    fun palette(dark: Boolean): Palette =
        if (dark) Palette(
            bg = INK,
            surface = withAlpha(BLUE, 0x26),
            text = CREAM,
            sub = withAlpha(CREAM, 0xB3),
            label = CYAN,
            onHeader = CREAM,
            onHeaderSub = withAlpha(CREAM, 0xB3),
            border = withAlpha(CYAN, 0x66),
            tints = intArrayOf(CYAN, BLUE, MINT, BLUSH)
        ) else Palette(
            bg = CREAM,
            surface = BLUSH,
            text = INK,
            sub = withAlpha(INK, 0xB3),
            label = INK,
            onHeader = INK,
            onHeaderSub = withAlpha(INK, 0xB3),
            border = withAlpha(INK, 0x26),
            tints = intArrayOf(CYAN, BLUE, INK, SKY_TINT)
        )

    fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)
}

/** Small helper shared by every screen: dp conversion, palette and common drawables. */
class Ui(val ctx: Context, val dark: Boolean) {
    val pal: Tally.Palette = Tally.palette(dark)
    private val d = ctx.resources.displayMetrics.density

    init { Tally.dark = dark }

    fun px(v: Int): Int = (v * d).toInt()
    fun pxf(v: Float): Float = v * d

    fun cardBg(
        radiusDp: Int = 14,
        fill: Int = pal.surface,
        stroke: Int = pal.border,
        strokeDp: Int = 1
    ): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = pxf(radiusDp.toFloat())
        if (strokeDp > 0) g.setStroke(px(strokeDp), stroke)
        return g
    }

    /** Soft blue wash pill with a cyan bar on the left, used for the selected or highlighted row. */
    fun highlight(): LayerDrawable {
        val fill = GradientDrawable()
        fill.setColor(Tally.withAlpha(Tally.BLUE, 0x26))
        fill.cornerRadius = pxf(10f)
        val bar = GradientDrawable()
        bar.setColor(Tally.CYAN)
        bar.cornerRadius = pxf(2f)
        val ld = LayerDrawable(arrayOf<Drawable>(fill, bar))
        ld.setLayerWidth(1, px(4))
        ld.setLayerGravity(1, Gravity.START or Gravity.FILL_VERTICAL)
        ld.setLayerInsetTop(1, px(8))
        ld.setLayerInsetBottom(1, px(8))
        return ld
    }

    fun stateHighlight(): StateListDrawable {
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_pressed), highlight())
        s.addState(intArrayOf(android.R.attr.state_focused), highlight())
        s.addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
        return s
    }
}
