package com.kshitij.minilauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

class AppItem(val label: String, val pkg: String, val cls: String, val category: Int)
class WebRow(val query: String)
/** Header row in the grouped view. Tapping it collapses or expands the section. */
class Section(val key: String, val name: String, val count: Int, val collapsed: Boolean, val tintIndex: Int)

class MainActivity : Activity() {

    companion object {
        // App Tray presentation modes. Stored as an int in prefs "drawerMode".
        const val MODE_LIST = 0      // classic alphabetical list with fast-scroll letters
        const val MODE_GRID = 1      // 4 or 5 column squircle grid
        const val MODE_GROUPS = 2    // categorised, collapsible sections
        const val MODE_PAGES = 3     // swipeable horizontal pages of 3 x 4 apps
        const val PAGE_SIZE = 12
        val MODE_NAMES = arrayOf("List", "Grid", "Groups", "Pages")
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var ui: Ui
    private lateinit var pal: Tally.Palette
    private lateinit var icons: IconProvider
    private lateinit var widgets: Widgets
    private lateinit var shade: Shade
    private var dark = false

    private var allApps: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()   // apps matching the search
    private var rows: List<Any> = emptyList()        // String = letter, Section, AppItem, WebRow

    private var mode = MODE_LIST
    private var gridCols = 4

    private lateinit var home: FrameLayout
    private lateinit var favBox: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var switcher: LinearLayout
    private lateinit var list: ListView
    private lateinit var grid: GridView
    private lateinit var pager: HorizontalScrollView
    private lateinit var pagesBox: LinearLayout
    private lateinit var dotsBox: LinearLayout
    private lateinit var sidebar: LinearLayout
    private lateinit var adapter: BaseAdapter
    private lateinit var gridAdapter: BaseAdapter
    private lateinit var gestures: GestureDetector
    private val modeChips = ArrayList<TextView>()
    private val dots = ArrayList<View>()

    private val autoLaunch: Boolean get() = prefs.getBoolean("auto", false)
    private val customShade: Boolean get() = prefs.getBoolean("customShade", true)
    private fun px(v: Int): Int = ui.px(v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun isDark(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private lateinit var unlockSweep: UnlockSweepView
    private var unlockRegistered = false
    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action == Intent.ACTION_USER_PRESENT || i?.action == Intent.ACTION_SCREEN_ON) unlockSweep.play()
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { widgets.updateBattery(i) }
    }
    private var batteryRegistered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        dark = isDark()
        ui = Ui(this, dark)
        pal = ui.pal
        icons = IconProvider(this, ui)
        widgets = Widgets(ui)
        mode = prefs.getInt("drawerMode", MODE_LIST).coerceIn(0, 3)
        gridCols = prefs.getInt("gridCols", 4).coerceIn(4, 5)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        val root = FrameLayout(this)
        root.setBackgroundColor(pal.bg)
        buildHome()
        buildDrawer()
        shade = Shade(this, ui, { closeShade() }, { closeShade(); expandSystemShade() })
        root.addView(home, FrameLayout.LayoutParams(-1, -1))
        unlockSweep = UnlockSweepView(this)
        root.addView(unlockSweep, FrameLayout.LayoutParams(-1, -1))
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
        root.addView(shade.root, FrameLayout.LayoutParams(-1, -1))
        drawer.visibility = View.GONE
        setContentView(root)
        applySystemBars()
        if (savedInstanceState == null) unlockSweep.post { unlockSweep.play() }

        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || drawer.visibility == View.VISIBLE || shade.isVisible) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                val min = px(80)
                if (abs(dy) > abs(dx)) {
                    if (dy < -min) openDrawer() else if (dy > min) openShadeOrSystem()
                } else {
                    if (dx < -min) openCamera() else if (dx > min) openDialer()
                }
                return true
            }
        })
        gestures.setIsLongpressEnabled(false)
    }

    /** Status bar and navigation bar colours plus icon flags to match the brand palette. */
    @Suppress("DEPRECATION")
    private fun applySystemBars() {
        window.statusBarColor = if (dark) Tally.INK else Tally.SKY_TINT
        window.navigationBarColor = pal.bg
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val c = window.insetsController
            if (c != null) {
                // dark icons on the light sky-tint bar; light icons on the dark bar
                c.setSystemBarsAppearance(
                    if (dark) 0 else WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                )
                c.setSystemBarsAppearance(
                    if (dark) 0 else WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                )
            }
        } else {
            val v = window.decorView
            var f = v.systemUiVisibility
            f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            v.systemUiVisibility = f
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (isDark() != dark) recreate()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_G && event.isAltPressed) {
            if (shade.isVisible) closeShade()
            openDrawer()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        refreshFavs()
        filter()
        widgets.updateCalendar()
        registerBattery()
        registerUnlock()
        shade.onResume()
    }

    private fun registerUnlock() {
        if (unlockRegistered) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(unlockReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(unlockReceiver, f)
        unlockRegistered = true
    }

    private fun unregisterUnlock() {
        if (!unlockRegistered) return
        try { unregisterReceiver(unlockReceiver) } catch (e: Exception) { }
        unlockRegistered = false
    }

    override fun onPause() {
        super.onPause()
        unregisterBattery()
        unregisterUnlock()
        unlockSweep.cancelPlay()
    }

    override fun onDestroy() {
        super.onDestroy()
        shade.destroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        closeDrawer()
        closeShade()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (shade.isVisible) closeShade()
        else if (drawer.visibility == View.VISIBLE) closeDrawer()
    }

    private fun registerBattery() {
        if (batteryRegistered) return
        val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val sticky = if (Build.VERSION.SDK_INT >= 33) registerReceiver(batteryReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(batteryReceiver, f)
        batteryRegistered = true
        widgets.updateBattery(sticky)
    }

    private fun unregisterBattery() {
        if (!batteryRegistered) return
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) { }
        batteryRegistered = false
    }

    // ---------- Home ----------

    private fun contentWidth(): Int = px(min(resources.configuration.screenWidthDp, 560))

    private fun buildHome() {
        home = FrameLayout(this)

        // Bottom-right corner swoosh. Not clickable, so touches fall through to the content.
        home.addView(
            SwooshView(this, SwooshView.CORNER_BR),
            FrameLayout.LayoutParams(px(200), px(160), Gravity.BOTTOM or Gravity.END)
        )

        val header = SwooshView(this, SwooshView.HEADER_HOME)
        header.setOnClickListener { openShadeOrSystem() }
        header.setOnLongClickListener { showSettings(); true }
        home.addView(header, FrameLayout.LayoutParams(-1, px(140), Gravity.TOP))

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(px(16), px(4), px(16), px(40))

        // status header row: tap for the in-launcher quick settings
        val status = LinearLayout(this)
        status.orientation = LinearLayout.HORIZONTAL
        status.gravity = Gravity.CENTER_VERTICAL
        status.isClickable = true
        status.setOnClickListener { openShadeOrSystem() }
        val appName = TextView(this)
        appName.text = "MINI LAUNCHER"
        appName.textSize = 11f
        appName.letterSpacing = 0.22f
        appName.setTextColor(pal.onHeaderSub)
        status.addView(appName, LinearLayout.LayoutParams(0, -2, 1f))
        val qs = TextView(this)
        qs.text = "Quick settings \u25BE"
        qs.textSize = 12f
        qs.setTextColor(Tally.BLUE)
        status.addView(qs)
        content.addView(status, LinearLayout.LayoutParams(-1, px(36)))

        val cl = LinearLayout.LayoutParams(-1, -2)
        cl.setMargins(0, px(88), 0, 0)
        content.addView(widgets.clock { showSettings() }, cl)
        val gl = LinearLayout.LayoutParams(-1, px(52))
        gl.setMargins(0, px(14), 0, 0)
        content.addView(widgets.goTo { openDrawer() }, gl)
        val sl = LinearLayout.LayoutParams(-1, px(108))
        sl.setMargins(0, px(14), 0, 0)
        content.addView(widgets.stats {
            try {
                startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { toast("No calendar app found") }
        }, sl)

        val label = TextView(this)
        label.text = "PINNED"
        label.textSize = 12f
        label.letterSpacing = 0.15f
        label.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        label.setTextColor(pal.label)
        label.setPadding(px(8), px(14), 0, 0)
        content.addView(label)
        content.addView(SwooshView(this, SwooshView.GOLD_DIV), LinearLayout.LayoutParams(-1, px(16)))

        favBox = LinearLayout(this)
        favBox.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(favBox, FrameLayout.LayoutParams(-1, -2))
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        home.addView(content, FrameLayout.LayoutParams(contentWidth(), -1, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // Tiny, non-prominent signature in the bottom-left corner.
        val sig = TextView(this)
        sig.text = "Kshitij"
        sig.textSize = 9f
        sig.letterSpacing = 0.12f
        sig.setTextColor(Tally.withAlpha(pal.sub, 120))
        val sigLp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START)
        sigLp.setMargins(px(14), 0, 0, px(10))
        home.addView(sig, sigLp)
    }

    private fun refreshFavs() {
        favBox.removeAllViews()
        val favs = getFavs().mapNotNull { p -> allApps.firstOrNull { it.pkg == p } }
        if (favs.isEmpty()) {
            val hint = TextView(this)
            hint.text = "Swipe up for all apps. Long-press an app to pin it here.\nLong-press the header for settings and to switch back to your old launcher."
            hint.setTextColor(pal.sub)
            hint.textSize = 13f
            hint.setPadding(px(8), px(8), px(8), 0)
            favBox.addView(hint)
        }
        for (a in favs) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(px(12), px(6), px(12), px(6))
            row.background = ui.stateHighlight()
            row.isFocusable = true
            val iv = ImageView(this)
            icons.bind(iv, a, true)
            row.addView(iv, LinearLayout.LayoutParams(px(44), px(44)))
            val t = TextView(this)
            t.text = a.label
            t.textSize = 19f
            t.setTextColor(pal.text)
            t.setPadding(px(16), 0, 0, 0)
            row.addView(t)
            row.setOnClickListener { launch(a) }
            row.setOnLongClickListener { showAppMenu(a); true }
            favBox.addView(row)
        }
    }

    // ---------- Drawer (App Tray) ----------

    private fun buildDrawer() {
        drawer = LinearLayout(this)
        drawer.orientation = LinearLayout.VERTICAL
        drawer.setBackgroundColor(pal.bg)

        val headerHolder = FrameLayout(this)
        headerHolder.addView(SwooshView(this, SwooshView.HEADER_DRAWER), FrameLayout.LayoutParams(-1, -1))

        val title = TextView(this)
        title.text = "All Apps"
        title.textSize = 18f
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.setTextColor(pal.onHeader)
        title.setPadding(px(28), px(20), 0, 0)
        headerHolder.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(px(14), 0, px(12), 0)
        bar.background = ui.cardBg(12, pal.surface, Tally.BLUE, 2)
        bar.elevation = px(4).toFloat()
        bar.addView(SearchIconView(this, Tally.BLUE), LinearLayout.LayoutParams(px(20), px(20)))

        search = EditText(this)
        search.hint = "Go To  \u2013  type an app name"
        search.setHintTextColor(pal.sub)
        search.setTextColor(pal.text)
        search.textSize = 18f
        search.setSingleLine(true)
        search.background = null
        search.setPadding(px(10), 0, 0, 0)
        search.imeOptions = EditorInfo.IME_ACTION_GO
        search.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter() }
        })
        search.setOnEditorActionListener { _, _, _ ->
            val q = search.text.toString().trim()
            if (shown.isNotEmpty()) launch(shown[0]) else if (q.isNotEmpty()) webSearch(q)
            true
        }
        bar.addView(search, LinearLayout.LayoutParams(0, -1, 1f))

        val barLp = FrameLayout.LayoutParams(-1, px(52), Gravity.BOTTOM)
        barLp.setMargins(px(24), 0, px(24), px(18))
        headerHolder.addView(bar, barLp)

        drawer.addView(headerHolder, LinearLayout.LayoutParams(-1, px(176)))
        drawer.addView(buildSwitcher(), LinearLayout.LayoutParams(-1, px(46)))

        val body = FrameLayout(this)
        body.addView(buildList(), FrameLayout.LayoutParams(-1, -1))
        body.addView(buildGrid(), FrameLayout.LayoutParams(-1, -1))
        body.addView(buildPager(), FrameLayout.LayoutParams(-1, -1))

        sidebar = buildLetterSidebar()
        body.addView(sidebar, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))

        // page dots for the Pages mode, along the bottom-left edge of the body
        val dotsLp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START)
        dotsLp.setMargins(px(16), 0, 0, px(14))
        body.addView(dotsBox, dotsLp)

        // Bottom-right corner swoosh for the App Tray. Not clickable, so touches pass through.
        body.addView(
            SwooshView(this, SwooshView.CORNER_BR),
            FrameLayout.LayoutParams(px(200), px(160), Gravity.BOTTOM or Gravity.END)
        )
        drawer.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        showMode(mode, animate = false)
    }

    /** Layout switcher row: List, Grid, Groups, Pages. Tapping the active Grid chip toggles 4 and 5 columns. */
    private fun buildSwitcher(): LinearLayout {
        switcher = LinearLayout(this)
        switcher.orientation = LinearLayout.HORIZONTAL
        switcher.gravity = Gravity.CENTER_VERTICAL
        switcher.setPadding(px(16), px(4), px(16), px(4))
        for (i in MODE_NAMES.indices) {
            val chip = TextView(this)
            chip.textSize = 13f
            chip.gravity = Gravity.CENTER
            chip.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            chip.setPadding(px(6), 0, px(6), 0)
            chip.setOnClickListener {
                if (i == MODE_GRID && mode == MODE_GRID) {
                    gridCols = if (gridCols == 4) 5 else 4
                    prefs.edit().putInt("gridCols", gridCols).apply()
                    grid.numColumns = gridCols
                    updateChips()
                    gridAdapter.notifyDataSetChanged()
                } else {
                    setMode(i)
                }
            }
            modeChips.add(chip)
            val lp = LinearLayout.LayoutParams(0, px(34), 1f)
            lp.setMargins(px(3), 0, px(3), 0)
            switcher.addView(chip, lp)
        }
        updateChips()
        return switcher
    }

    private fun updateChips() {
        for (i in modeChips.indices) {
            val active = i == mode
            val chip = modeChips[i]
            chip.text = if (i == MODE_GRID) "Grid $gridCols" else MODE_NAMES[i]
            chip.background = if (active) ui.cardBg(12, Tally.BLUE, Tally.BLUE, 0)
            else ui.cardBg(12, pal.surface, pal.border, 1)
            chip.setTextColor(if (active) Tally.INK else pal.sub)
        }
    }

    private fun setMode(m: Int) {
        if (m == mode) return
        mode = m
        prefs.edit().putInt("drawerMode", m).apply()
        showMode(m, animate = true)
        rebuildRows()
    }

    /** Shows one presentation mode and hides the rest, with a short fade so switching feels smooth. */
    private fun showMode(m: Int, animate: Boolean) {
        updateChips()
        val target: View = when (m) {
            MODE_GRID -> grid
            MODE_PAGES -> pager
            else -> list
        }
        for (v in listOf<View>(list, grid, pager)) v.visibility = if (v === target) View.VISIBLE else View.GONE
        sidebar.visibility = if (m == MODE_LIST) View.VISIBLE else View.GONE
        dotsBox.visibility = if (m == MODE_PAGES) View.VISIBLE else View.GONE
        if (animate) {
            target.alpha = 0f
            target.animate().alpha(1f).setDuration(180).start()
        } else target.alpha = 1f
    }

    private fun buildList(): ListView {
        list = ListView(this)
        list.divider = null
        list.overScrollMode = View.OVER_SCROLL_NEVER
        list.selector = ui.highlight()
        list.setDrawSelectorOnTop(false)
        list.setPadding(px(16), px(8), px(16), px(8))
        list.clipToPadding = false
        list.setFastScrollEnabled(false)

        adapter = object : BaseAdapter() {
            override fun getCount(): Int = rows.size
            override fun getItem(i: Int): Any = rows[i]
            override fun getItemId(i: Int): Long = i.toLong()
            override fun getViewTypeCount(): Int = 4
            override fun getItemViewType(i: Int): Int = when (rows[i]) {
                is String -> 0
                is AppItem -> 1
                is Section -> 3
                else -> 2
            }
            override fun areAllItemsEnabled(): Boolean = false
            override fun isEnabled(i: Int): Boolean = rows[i] !is String
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val r = rows[i]
                if (r is String) {
                    val box = (v as? LinearLayout) ?: buildLetterRow()
                    (box.getChildAt(0) as TextView).text = r
                    return box
                }
                if (r is Section) {
                    val row = (v as? LinearLayout) ?: buildSectionRow()
                    bindSection(row, r)
                    return row
                }
                if (r is WebRow) {
                    val row = (v as? LinearLayout) ?: buildWebRow()
                    (row.getChildAt(1) as TextView).text = "Search the web for \u201C" + r.query + "\u201D"
                    return row
                }
                val a = r as AppItem
                val row = (v as? LinearLayout) ?: buildAppRow()
                icons.bind(row.getChildAt(0) as ImageView, a, a.pkg in getFavs())
                (row.getChildAt(1) as TextView).text = a.label
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, i, _ ->
            when (val r = rows[i]) {
                is AppItem -> launch(r)
                is WebRow -> webSearch(r.query)
                is Section -> toggleSection(r.key)
                else -> {}
            }
        }
        list.setOnItemLongClickListener { _, _, i, _ ->
            val r = rows[i]
            if (r is AppItem) showAppMenu(r)
            true
        }
        return list
    }

    /** Grid: square tinted cells with the icon and label, 4 or 5 columns. */
    private fun buildGrid(): GridView {
        grid = GridView(this)
        grid.numColumns = gridCols
        grid.horizontalSpacing = px(6)
        grid.verticalSpacing = px(10)
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.overScrollMode = View.OVER_SCROLL_NEVER
        grid.setPadding(px(12), px(8), px(12), px(96))
        grid.clipToPadding = false
        gridAdapter = object : BaseAdapter() {
            override fun getCount(): Int = shown.size
            override fun getItem(i: Int): Any = shown[i]
            override fun getItemId(i: Int): Long = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                return buildAppCell(shown[i], i, grid = true)
            }
        }
        grid.adapter = gridAdapter
        return grid
    }

    /** Pages: swipeable horizontal pages of 3 x 4 apps, with dots at the bottom. Pinned apps lead. */
    private fun buildPager(): HorizontalScrollView {
        pager = HorizontalScrollView(this)
        pager.isHorizontalScrollBarEnabled = false
        pager.overScrollMode = View.OVER_SCROLL_NEVER
        pagesBox = LinearLayout(this)
        pagesBox.orientation = LinearLayout.HORIZONTAL
        pager.addView(pagesBox, FrameLayout.LayoutParams(-2, -1))
        pager.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                pager.postDelayed({ snapToPage() }, 120)
            }
            false
        }
        pager.setOnScrollChangeListener { _, x, _, _, _ -> updateDots(pageWidth().let { w -> (x / w.toFloat()).roundToInt() }) }

        // dots sit above the swoosh corner, so they stay on the left of the bottom edge
        dotsBox = LinearLayout(this)
        dotsBox.orientation = LinearLayout.HORIZONTAL
        dotsBox.gravity = Gravity.CENTER
        return pager
    }

    private fun pageWidth(): Int = resources.displayMetrics.widthPixels

    private fun snapToPage() {
        val pw = pageWidth()
        val target = (pager.scrollX / pw.toFloat()).roundToInt() * pw
        pager.smoothScrollTo(target, 0)
    }

    private fun updateDots(active: Int) {
        for ((i, d) in dots.withIndex()) {
            (d.background as? GradientDrawable)?.setColor(if (i == active) Tally.BLUE else pal.border)
        }
    }

    private fun rebuildPages() {
        pagesBox.removeAllViews()
        dots.clear()
        dotsBox.removeAllViews()
        val pw = pageWidth()
        val pinned = getFavs().mapNotNull { p -> shown.firstOrNull { it.pkg == p } }
        val pages = ArrayList<Pair<List<AppItem>, Boolean>>()
        pinned.chunked(PAGE_SIZE).forEach { pages.add(it to true) }
        shown.chunked(PAGE_SIZE).forEach { pages.add(it to false) }
        if (pages.isEmpty()) {
            val empty = TextView(this)
            empty.text = "No apps to show"
            empty.setTextColor(pal.sub)
            empty.gravity = Gravity.CENTER
            empty.layoutParams = LinearLayout.LayoutParams(pw, -1)
            pagesBox.addView(empty)
        }
        for ((page, isPinned) in pages) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(px(14), px(12), px(14), px(96))
            for (r in 0 until 4) {
                val line = LinearLayout(this)
                line.orientation = LinearLayout.HORIZONTAL
                for (c in 0 until 3) {
                    val idx = r * 3 + c
                    if (idx < page.size) {
                        line.addView(buildAppCell(page[idx], idx, grid = false),
                            LinearLayout.LayoutParams(0, px(116), 1f))
                    } else {
                        line.addView(View(this), LinearLayout.LayoutParams(0, px(116), 1f))
                    }
                }
                col.addView(line, LinearLayout.LayoutParams(-1, px(116)))
            }
            pagesBox.addView(col, LinearLayout.LayoutParams(pw, -1))
        }
        // page dots: active is blue; a red bar under a dot marks a page of pinned apps
        for ((i, pagePair) in pages.withIndex()) {
            val holder = LinearLayout(this)
            holder.orientation = LinearLayout.VERTICAL
            holder.gravity = Gravity.CENTER_HORIZONTAL
            val dot = View(this)
            dot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(pal.border) }
            holder.addView(dot, LinearLayout.LayoutParams(px(8), px(8)).apply { setMargins(px(5), 0, px(5), px(4)) })
            if (pagePair.second) {
                val pin = View(this)
                pin.background = GradientDrawable().apply { cornerRadius = px(2).toFloat(); setColor(Tally.RED) }
                holder.addView(pin, LinearLayout.LayoutParams(px(10), px(3)))
            }
            dots.add(dot)
            dotsBox.addView(holder)
        }
        updateDots(0)
        pager.scrollTo(0, 0)
    }

    private fun buildAppCell(a: AppItem, index: Int, grid: Boolean): LinearLayout {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.setPadding(px(4), px(6), px(4), px(6))
        val tints = Tally.cellTints()
        val tint = tints[index % tints.size]
        val box = FrameLayout(this)
        box.background = ui.cardBg(18, tint, tint, 0)
        val iv = ImageView(this)
        val size = if (grid) px(50) else px(54)
        box.addView(iv, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
        icons.bind(iv, a, a.pkg in getFavs())
        cell.addView(box, LinearLayout.LayoutParams(px(if (grid) 66 else 68), px(if (grid) 66 else 68)))
        val t = TextView(this)
        t.text = a.label
        t.textSize = 12f
        t.maxLines = 1
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        t.gravity = Gravity.CENTER
        t.setTextColor(pal.text)
        t.setPadding(0, px(6), 0, 0)
        cell.addView(t, LinearLayout.LayoutParams(-1, -2))
        cell.isClickable = true
        cell.setOnClickListener { launch(a) }
        cell.setOnLongClickListener { showAppMenu(a); true }
        return cell
    }

    /** Fast-scroll alphabet on the right edge of the list. Tap or drag a letter to jump to it. */
    private fun buildLetterSidebar(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setPadding(px(2), 0, px(4), 0)
        val letters = ('A'..'Z').map { it.toString() } + "#"
        for (l in letters) {
            val t = TextView(this)
            t.text = l
            t.textSize = 10f
            t.gravity = Gravity.CENTER
            t.setTextColor(Tally.BLUE)
            t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            box.addView(t, LinearLayout.LayoutParams(px(18), px(16)))
        }
        val letterList = letters
        box.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    val idx = (ev.y / (v.height.toFloat() / letterList.size)).toInt().coerceIn(0, letterList.size - 1)
                    scrollToLetter(letterList[idx])
                    true
                }
                else -> true
            }
        }
        return box
    }

    private fun scrollToLetter(letter: String) {
        var idx = rows.indexOfFirst { it is String && it == letter }
        if (idx < 0) idx = rows.indexOfFirst { it is String && it > letter }
        if (idx >= 0) list.setSelection(idx)
    }

    private fun buildAppRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(px(12), px(7), px(12), px(7))
        row.addView(ImageView(this), LinearLayout.LayoutParams(px(44), px(44)))
        val t = TextView(this)
        t.textSize = 19f
        t.setTextColor(pal.text)
        t.setPadding(px(16), 0, 0, 0)
        row.addView(t)
        return row
    }

    private fun buildWebRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(px(12), px(7), px(12), px(7))
        val box = FrameLayout(this)
        box.background = ui.cardBg(13, pal.surface, Tally.BLUE, 2)
        box.addView(SearchIconView(this, Tally.BLUE), FrameLayout.LayoutParams(px(22), px(22), Gravity.CENTER))
        row.addView(box, LinearLayout.LayoutParams(px(44), px(44)))
        val t = TextView(this)
        t.textSize = 16f
        t.setTextColor(Tally.BLUE)
        t.setPadding(px(16), 0, 0, 0)
        row.addView(t)
        return row
    }

    private fun buildLetterRow(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(px(4), px(14), px(4), 0)
        val t = TextView(this)
        t.textSize = 13f
        t.letterSpacing = 0.1f
        t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        t.setTextColor(pal.label)
        t.setPadding(px(12), 0, 0, px(2))
        box.addView(t)
        box.addView(SwooshView(this, SwooshView.TEAL_DIV), LinearLayout.LayoutParams(-1, px(12)))
        return box
    }

    /** Grouped view header: a sky-tint or mint band with the section name, count and a chevron. */
    private fun buildSectionRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(px(14), px(10), px(14), px(10))
        val name = TextView(this)
        name.textSize = 14f
        name.letterSpacing = 0.06f
        name.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        name.setTextColor(pal.onHeader)
        row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        val chev = TextView(this)
        chev.textSize = 13f
        chev.setTextColor(pal.onHeader)
        row.addView(chev)
        return row
    }

    private fun bindSection(row: LinearLayout, s: Section) {
        val band = if (s.tintIndex % 2 == 0) Tally.SKY_TINT else Tally.MINT
        row.background = ui.cardBg(10, if (dark) Tally.withAlpha(Tally.BLUE, 0x33) else band, band, 0)
        val name = row.getChildAt(0) as TextView
        name.text = "${s.name}  \u00B7  ${s.count}"
        val chev = row.getChildAt(1) as TextView
        chev.text = if (s.collapsed) "\u25B8" else "\u25BE"
    }

    private fun collapsedSet(): MutableSet<String> =
        HashSet(prefs.getStringSet("collapsed", emptySet()) ?: emptySet())

    private fun toggleSection(key: String) {
        val c = collapsedSet()
        if (!c.add(key)) c.remove(key)
        prefs.edit().putStringSet("collapsed", c).apply()
        rebuildRows()
    }

    // ---------- Apps ----------

    private fun loadApps() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = packageManager.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppItem(
                    it.loadLabel(packageManager).toString(),
                    it.activityInfo.packageName,
                    it.activityInfo.name,
                    it.activityInfo.applicationInfo.category
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun matches(label: String, q: String): Boolean {
        if (label.contains(q)) return true
        var i = 0
        for (c in label) {
            if (i < q.length && c == q[i]) i++
        }
        return i == q.length
    }

    /** Letter headers for the classic list. */
    private fun group(apps: List<AppItem>): List<Any> {
        val out = ArrayList<Any>()
        var last = ""
        for (a in apps) {
            val c = a.label.trim().firstOrNull()?.uppercaseChar()
            val key = if (c != null && c.isLetter()) c.toString() else "#"
            if (key != last) {
                out.add(key)
                last = key
            }
            out.add(a)
        }
        return out
    }

    /** Category for the grouped view. Anything unlabelled by Android goes to Utilities. */
    private fun sectionFor(category: Int): String = when (category) {
        ApplicationInfo.CATEGORY_SOCIAL, ApplicationInfo.CATEGORY_NEWS -> "Communication"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Work & Finance"
        ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO,
        ApplicationInfo.CATEGORY_IMAGE, ApplicationInfo.CATEGORY_GAME -> "Media"
        else -> "Utilities"
    }

    /** Sections in display order: Pinned first, then the categories. Empty sections are skipped. */
    private fun groupedRows(apps: List<AppItem>): List<Any> {
        val out = ArrayList<Any>()
        val collapsed = collapsedSet()
        val pinned = getFavs().mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
        val buckets = linkedMapOf(
            "Pinned" to pinned,
            "Communication" to ArrayList<AppItem>(),
            "Work & Finance" to ArrayList<AppItem>(),
            "Media" to ArrayList<AppItem>(),
            "Utilities" to ArrayList<AppItem>()
        )
        for (a in apps) (buckets[sectionFor(a.category)] as ArrayList<AppItem>).add(a)
        var tint = 0
        for ((name, items) in buckets) {
            if (items.isEmpty()) continue
            val key = "sec:$name"
            val isCollapsed = key in collapsed
            out.add(Section(key, name, items.size, isCollapsed, tint++))
            if (!isCollapsed) out.addAll(items)
        }
        return out
    }

    private fun filter() {
        val q = search.text.toString().trim().lowercase()
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        val base = allApps.filter { it.pkg !in hidden }
        shown = if (q.isEmpty()) base
        else base.filter { matches(it.label.lowercase(), q) }
            .sortedBy { if (it.label.lowercase().startsWith(q)) 0 else 1 }
        rebuildRows()
        if (autoLaunch && q.length >= 2 && shown.size == 1) launch(shown[0])
    }

    /** Rebuilds whichever presentation is showing. The list and groups views use rows, the others use shown. */
    private fun rebuildRows() {
        val typed = search.text.toString().trim()
        rows = when {
            typed.isNotEmpty() -> {
                val r = ArrayList<Any>(shown)
                if (mode == MODE_LIST || mode == MODE_GROUPS) r.add(WebRow(typed))
                r
            }
            mode == MODE_GROUPS -> groupedRows(shown)
            else -> group(shown)
        }
        adapter.notifyDataSetChanged()
        gridAdapter.notifyDataSetChanged()
        rebuildPages()
    }

    private fun webSearch(q: String) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) { toast("No browser found") }
        closeDrawer()
    }

    private fun launch(a: AppItem) {
        try {
            val i = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(a.pkg, a.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(i)
        } catch (e: Exception) {
            toast("Can't open ${a.label}")
        }
        closeDrawer()
    }

    private fun getFavs(): List<String> =
        (prefs.getString("favs", "") ?: "").split("\n").filter { it.isNotEmpty() }

    private fun setFavs(l: List<String>) {
        prefs.edit().putString("favs", l.joinToString("\n")).apply()
    }

    @Suppress("DEPRECATION")
    private fun dialogTheme(): Int =
        if (dark) AlertDialog.THEME_DEVICE_DEFAULT_DARK else AlertDialog.THEME_DEVICE_DEFAULT_LIGHT

    private fun showAppMenu(a: AppItem) {
        val isFav = a.pkg in getFavs()
        val items = arrayOf(
            if (isFav) "Remove from home" else "Pin to home",
            "Hide",
            "App info",
            "Uninstall"
        )
        AlertDialog.Builder(this, dialogTheme())
            .setTitle(a.label)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        val f = getFavs().toMutableList()
                        if (isFav) f.remove(a.pkg)
                        else if (f.size >= 6) toast("Home is full (6 apps)")
                        else f.add(a.pkg)
                        setFavs(f)
                    }
                    1 -> {
                        val s = HashSet(prefs.getStringSet("hidden", emptySet()) ?: emptySet())
                        s.add(a.pkg)
                        prefs.edit().putStringSet("hidden", s).apply()
                        setFavs(getFavs().filter { it != a.pkg })
                        toast("Hidden. Unhide from the header long-press menu.")
                    }
                    2 -> safe {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
                        )
                    }
                    3 -> safe {
                        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                    }
                }
                refreshFavs()
                filter()
            }
            .show()
    }

    private fun showSettings() {
        val items = arrayOf(
            "Switch back to default launcher",
            "Swipe down opens: " + (if (customShade) "Quick panel" else "System shade"),
            "Auto-open single search match: " + (if (autoLaunch) "ON" else "OFF"),
            "Unhide all apps",
            "System settings"
        )
        AlertDialog.Builder(this, dialogTheme())
            .setTitle("Mini Launcher")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> switchLauncher()
                    1 -> prefs.edit().putBoolean("customShade", !customShade).apply()
                    2 -> prefs.edit().putBoolean("auto", !autoLaunch).apply()
                    3 -> { prefs.edit().remove("hidden").apply(); filter() }
                    4 -> safe { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                }
            }
            .show()
    }

    /**
     * Opens the system Home app picker so the user can choose their old launcher again.
     * Only opens Android settings. It does not change or remove any Mini Launcher data.
     */
    private fun switchLauncher() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                Toast.makeText(
                    this,
                    "Open Apps > Default apps > Home app and pick your old launcher",
                    Toast.LENGTH_LONG
                ).show()
            } catch (e2: Exception) {
                toast("Open Settings > Apps > Default apps > Home app")
            }
        }
    }

    // ---------- Drawer, shade + gestures ----------

    private fun openDrawer() {
        drawer.visibility = View.VISIBLE
        search.requestFocus()
        search.post {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closeDrawer() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.setText("")
        drawer.visibility = View.GONE
    }

    private fun openShadeOrSystem() {
        if (customShade) shade.show() else expandSystemShade()
    }

    private fun closeShade() = shade.hide()

    private fun expandSystemShade() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager")
                .getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) {
            toast("Pull down from the top edge")
        }
    }

    private fun openCamera() = safe { startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
    private fun openDialer() = safe { startActivity(Intent(Intent.ACTION_DIAL)) }

    private fun safe(block: () -> Unit) {
        try { block() } catch (e: Exception) { toast("Not available on this device") }
    }
}
